"""
Integration Tests for RE-TWIN SOH, RUL, and Anomaly Detection Model Integration.

Validates:
- Model status management (TRAINED_AND_VALIDATED, DATA_UNAVAILABLE, MODEL_NOT_TRAINED, INPUT_FEATURES_UNAVAILABLE, MODEL_INPUT_INCOMPATIBLE).
- Missing model file handling without crash or fabricated predictions.
- Missing feature handling without crash.
- SOH Linear Regression baseline preservation and XGBoost discovery.
- RUL prediction unit ("Cycles remaining") and un-trained model state.
- Anomaly score (-decision_function), flag, operating context, and probability disclaimer.
- Data provenance tags (REAL, DERIVED, SIMULATED, MODEL ESTIMATE).
- Digital Twin Core & Health & Risk Engine integration.
"""

import pytest
import numpy as np
import pandas as pd
from pathlib import Path

from src.core.battery_state import BatteryPackSpec, DataCategory
from src.ml.model_status import get_model_status, ModelStatus
from src.ml.soh_predictor import SOHPredictor
from src.ml.rul_predictor import RULPredictor
from src.ml.anomaly_detector import AnomalyDetector
from src.twin.digital_twin_core import DigitalTwinEngine


@pytest.fixture
def sample_telemetry():
    return {
        "PackVoltage": 32.1,
        "PackCurrent": 12.5,
        "PackPower_W": 401.25,
        "SOC": 82.5,
        "TempMean": 26.2,
        "CellVoltageImbalance": 0.006,
        "Throughput_Ah": 124.0,
        "charging_current_limit_command": 14.0,
        "charging_current_limit_reply": 14.0,
        "charge_current_a": 13.4
    }


def test_model_status_enum_and_helper(sample_telemetry):
    # Test un-trained RUL predictor status
    fake_predictor = RULPredictor(model_path="models/non_existent_rul_model.joblib")
    status = get_model_status(
        fake_predictor,
        snapshot_dict=sample_telemetry,
        expected_model_path="models/non_existent_rul_model.joblib",
        training_data_path="data/training/non_existent.csv"
    )

    assert status["status"] in (ModelStatus.MODEL_NOT_TRAINED.value, ModelStatus.DATA_UNAVAILABLE.value)
    assert status["is_usable"] is False
    assert status["missing_requirement"] is not None


def test_soh_predictor_baseline_integration(sample_telemetry):
    soh_path = Path("models/soh_linear_regression.joblib")
    predictor = SOHPredictor(model_path=soh_path if soh_path.exists() else None)
    soh_val, attribution = predictor.predict_single(sample_telemetry)

    assert 0.50 <= soh_val <= 0.99
    assert isinstance(attribution, dict)
    info = predictor.get_model_info()
    assert "Linear Regression" in info["model_architecture"]


def test_rul_predictor_missing_model_behavior(sample_telemetry):
    predictor = RULPredictor(model_path="models/rul_random_forest.joblib")
    status = get_model_status(
        predictor,
        snapshot_dict=sample_telemetry,
        expected_model_path="models/rul_random_forest.joblib"
    )

    if not Path("models/rul_random_forest.joblib").exists():
        assert status["status"] == ModelStatus.MODEL_NOT_TRAINED.value
        assert status["is_usable"] is False
        assert "Cycles remaining" in predictor.rul_unit


def test_anomaly_detector_isolation_forest(sample_telemetry):
    anom_path = Path("models/anomaly_isolation_forest.joblib")
    if anom_path.exists():
        detector = AnomalyDetector(model_path=anom_path)
        score, is_anom, diag = detector.predict_single(sample_telemetry)

        assert isinstance(score, float)
        assert isinstance(is_anom, bool)
        assert diag["anomaly_flag"] in ("ANOMALOUS", "NORMAL")
        assert "Level 2 AC Charging" in diag["operating_context"]
        assert "NOT" in diag["probability_disclaimer"]


def test_anomaly_detector_missing_features():
    anom_path = Path("models/anomaly_isolation_forest.joblib")
    if anom_path.exists():
        detector = AnomalyDetector(model_path=anom_path)
        # Snapshot missing Level 2 AC charging signals
        incomplete_telemetry = {"SOC": 80.0, "TempMean": 25.0}
        status = get_model_status(detector, snapshot_dict=incomplete_telemetry)

        assert status["status"] == ModelStatus.INPUT_FEATURES_UNAVAILABLE.value
        assert status["is_usable"] is False
        assert "charging_current_limit_command" in status["missing_features"]


def test_digital_twin_engine_health_and_risk(sample_telemetry):
    engine = DigitalTwinEngine()
    health_risk_out = engine.evaluate_health_and_risk(sample_telemetry)

    assert "vitals" in health_risk_out
    assert "soh" in health_risk_out["vitals"]
    assert "rul" in health_risk_out["vitals"]
    assert "anomaly_index" in health_risk_out["vitals"]
    assert "provenance" in health_risk_out

    vitals = health_risk_out["vitals"]
    assert vitals["soh"]["provenance"] == "MODEL ESTIMATE"
    assert vitals["rul"]["provenance"] == "MODEL ESTIMATE"
    assert vitals["rul"]["unit"] == "Cycles remaining"
    assert vitals["temperature"]["provenance"] == "REAL CAN DATA"
    assert vitals["internal_resistance"]["provenance"] == "SIMULATED EIS"
