"""
Unit and Integration Tests for Isolation Forest Operational Anomaly Detection Pipeline and Detector.
"""

import unittest
import tempfile
import json
from pathlib import Path
import pandas as pd
import numpy as np

from src.ml.anomaly_data_validation import (
    validate_anomaly_dataset,
    generate_anomaly_schema_and_readme,
    AnomalyDataValidationError,
    EXPECTED_ANOMALY_OPERATING_FEATURES
)
from src.ml.train_anomaly import train_anomaly_pipeline
from src.ml.anomaly_detector import AnomalyDetector, ANOMALY_FEATURES


class TestAnomalyPipeline(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.temp_path = Path(self.temp_dir.name)

        self.data_dir = self.temp_path / "data" / "training"
        self.model_dir = self.temp_path / "models"
        self.output_dir = self.temp_path / "output" / "ml_predictions"
        self.csv_path = self.data_dir / "anomaly_training.csv"

        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.model_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Generate realistic dataset representing Smart fortwo Level 2 AC charging session
        records = []
        np.random.seed(42)

        for i in range(50):
            # Normal steady charging (14A, SOC 94.2 -> 100.0%)
            soc = 94.2 + (i / 50.0) * 5.8
            curr = 13.64 + np.random.normal(0, 0.1)
            cmd = 14.0
            reply = 14.0
            records.append({
                "timestamp_raw": f"Sun Jun 24 13:{i:02d}:00 EDT 2018",
                "SOC": round(soc, 2),
                "charging_current_limit_command": cmd,
                "charging_current_limit_reply": reply,
                "charge_current_a": round(curr, 3),
                "operating_context": "Smart fortwo Level 2 AC Charging",
                "data_provenance": "Smart fortwo Real OBD/CAN Capture (Jun 2018)"
            })

        # Add 2 plausible anomaly rows (e.g. abrupt current drop to 0.5A while command is 14A)
        records.append({
            "timestamp_raw": "Sun Jun 24 13:51:00 EDT 2018",
            "SOC": 98.0,
            "charging_current_limit_command": 14.0,
            "charging_current_limit_reply": 14.0,
            "charge_current_a": 0.50,  # Abrupt drop
            "operating_context": "Smart fortwo Level 2 AC Charging",
            "data_provenance": "Smart fortwo Real OBD/CAN Capture (Jun 2018)"
        })

        self.valid_df = pd.DataFrame(records)
        self.valid_df.to_csv(self.csv_path, index=False)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_validate_anomaly_dataset_clean(self):
        validated_df, report = validate_anomaly_dataset(self.valid_df)
        self.assertEqual(report["total_input_rows"], 51)
        self.assertEqual(report["validated_output_rows"], 51)
        self.assertEqual(len(report["missing_features"]), 0)

    def test_validate_anomaly_dataset_missing_feature(self):
        bad_df = self.valid_df.drop(columns=["charge_current_a"])
        with self.assertRaises(AnomalyDataValidationError) as ctx:
            validate_anomaly_dataset(bad_df)
        self.assertIn("missing required anomaly features", str(ctx.exception).lower())

    def test_generate_anomaly_schema_and_readme(self):
        out_dir = self.temp_path / "training"
        schema_path, readme_path = generate_anomaly_schema_and_readme(out_dir)

        self.assertTrue(schema_path.exists())
        self.assertTrue(readme_path.exists())
        self.assertIn("README_ANOMALY.md", readme_path.name)
        self.assertIn("schema_anomaly.json", schema_path.name)

    def test_missing_dataset_handling(self):
        missing_csv = self.temp_path / "missing" / "anomaly_training.csv"
        missing_txt = self.temp_path / "missing" / "missing_source.txt"
        result = train_anomaly_pipeline(
            data_path=missing_csv,
            output_dir=self.output_dir,
            model_dir=self.model_dir,
            source_txt_path=missing_txt
        )

        self.assertEqual(result["status"], "MISSING_DATASET")
        self.assertTrue(Path(result["readme_path"]).exists())
        self.assertTrue(Path(result["schema_path"]).exists())

    def test_full_anomaly_pipeline_execution_and_artifacts(self):
        result = train_anomaly_pipeline(
            data_path=self.csv_path,
            output_dir=self.output_dir,
            model_dir=self.model_dir,
            contamination=0.05,
            random_seed=42
        )

        self.assertEqual(result["status"], "SUCCESS")

        model_file = self.model_dir / "anomaly_isolation_forest.joblib"
        meta_file = self.model_dir / "anomaly_isolation_forest_metadata.json"
        eval_file = self.output_dir / "anomaly_evaluation.json"
        scores_file = self.output_dir / "anomaly_scores.csv"

        self.assertTrue(model_file.exists())
        self.assertTrue(meta_file.exists())
        self.assertTrue(eval_file.exists())
        self.assertTrue(scores_file.exists())

        # Check metadata
        with open(meta_file, "r", encoding="utf-8") as f:
            meta = json.load(f)

        self.assertEqual(meta["model_architecture"], "Isolation Forest")
        self.assertIn("contamination_parameter", meta)
        self.assertIn("probability_disclaimer", meta)

        # Check analysis payload (Exploratory analysis - no false supervised metrics)
        with open(eval_file, "r", encoding="utf-8") as f:
            analysis = json.load(f)

        self.assertIn("score_distribution_statistics", analysis)
        self.assertIn("top_anomalous_observations", analysis)
        self.assertNotIn("precision", analysis)
        self.assertNotIn("recall", analysis)

        # Check scores CSV
        scores_df = pd.read_csv(scores_file)
        self.assertIn("anomaly_score", scores_df.columns)
        self.assertIn("anomaly_flag", scores_df.columns)

    def test_anomaly_detector_integration_and_unseen_inputs(self):
        train_anomaly_pipeline(
            data_path=self.csv_path,
            output_dir=self.output_dir,
            model_dir=self.model_dir,
            contamination=0.05,
            random_seed=42
        )

        model_file = self.model_dir / "anomaly_isolation_forest.joblib"
        detector = AnomalyDetector(model_path=model_file)

        self.assertEqual(detector.model_type, "Isolation Forest")
        self.assertEqual(detector.contamination, 0.05)

        # Test normal snapshot
        normal_snapshot = {
            "SOC": 96.0,
            "charging_current_limit_command": 14.0,
            "charging_current_limit_reply": 14.0,
            "charge_current_a": 13.64
        }
        score_norm, is_anom_norm, diag_norm = detector.predict_single(normal_snapshot)

        self.assertEqual(diag_norm["anomaly_flag"], "NORMAL")
        self.assertFalse(is_anom_norm)

        # Test extreme unseen anomalous snapshot
        extreme_snapshot = {
            "SOC": 99.0,
            "charging_current_limit_command": 14.0,
            "charging_current_limit_reply": 14.0,
            "charge_current_a": 0.10  # Very anomalous given 14A command
        }
        score_ext, is_anom_ext, diag_ext = detector.predict_single(extreme_snapshot)

        self.assertGreater(score_ext, score_norm)

    def test_anomaly_feature_validation_rejection(self):
        model_file = self.model_dir / "anomaly_isolation_forest.joblib"
        train_anomaly_pipeline(data_path=self.csv_path, output_dir=self.output_dir, model_dir=self.model_dir)

        detector = AnomalyDetector(model_path=model_file, strict_validation=True)
        bad_snapshot = {"SOC": "invalid_val"}

        with self.assertRaises(ValueError) as ctx:
            detector.predict_single(bad_snapshot)

        self.assertIn("Feature validation failed", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
