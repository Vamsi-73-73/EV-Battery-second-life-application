"""
Integration tests for XGBoost SOH Model Training Pipeline and Predictor.
"""

import unittest
import tempfile
import json
from pathlib import Path
import pandas as pd
import numpy as np
import joblib

from src.ml.train_soh import train_soh_pipeline
from src.ml.soh_predictor import SOHPredictor, FEATURES
from src.ml.data_validation import EXPECTED_OPERATING_FEATURES


class TestSOHXGBoostPipeline(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.temp_path = Path(self.temp_dir.name)

        self.data_dir = self.temp_path / "data" / "training"
        self.model_dir = self.temp_path / "models"
        self.output_dir = self.temp_path / "output" / "ml_predictions"
        self.csv_path = self.data_dir / "soh_training.csv"

        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.model_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Generate realistic multi-battery dataset for pipeline integration testing
        records = []
        battery_ids = ["BAT_01", "BAT_02", "BAT_03", "BAT_04", "BAT_05"]
        np.random.seed(42)

        for b_id in battery_ids:
            rated_cap = 50.0
            base_temp = 25.0 + np.random.uniform(-3, 3)
            for cycle in range(20):
                # Non-linear degradation curve
                meas_cap = rated_cap * (1.0 - 0.003 * cycle - 0.0001 * (cycle ** 1.5))
                records.append({
                    "battery_id": b_id,
                    "cycle_index": cycle,
                    "measured_capacity_ah": round(meas_cap, 4),
                    "rated_capacity_ah": rated_cap,
                    "SOC": round(80.0 - 0.2 * cycle, 2),
                    "TempMean": round(base_temp + 0.1 * cycle, 2),
                    "CellVoltageImbalance": round(0.005 + 0.0008 * cycle, 4),
                    "PackVoltage": round(32.0 - 0.05 * cycle, 2),
                    "PackCurrent": round(10.0 + np.random.normal(0, 0.5), 2),
                    "PackPower_W": round(320.0 + np.random.normal(0, 10), 1),
                    "Throughput_Ah": round(50.0 * (cycle + 1), 2)
                })

        self.train_df = pd.DataFrame(records)
        self.train_df.to_csv(self.csv_path, index=False)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_missing_dataset_handling(self):
        non_existent_csv = self.temp_path / "missing" / "soh_training.csv"
        result = train_soh_pipeline(
            data_path=non_existent_csv,
            output_dir=self.output_dir,
            model_dir=self.model_dir
        )

        self.assertEqual(result["status"], "MISSING_DATASET")
        self.assertTrue(Path(result["readme_path"]).exists())
        self.assertTrue(Path(result["schema_path"]).exists())

    def test_full_pipeline_execution_and_artifacts(self):
        result = train_soh_pipeline(
            data_path=self.csv_path,
            output_dir=self.output_dir,
            model_dir=self.model_dir,
            random_seed=42
        )

        self.assertEqual(result["status"], "SUCCESS")

        # Verify model files exist
        model_file = self.model_dir / "soh_xgboost.joblib"
        meta_file = self.model_dir / "soh_xgboost_metadata.json"
        eval_file = self.output_dir / "soh_evaluation.json"
        pred_file = self.output_dir / "soh_predictions.csv"

        self.assertTrue(model_file.exists())
        self.assertTrue(meta_file.exists())
        self.assertTrue(eval_file.exists())
        self.assertTrue(pred_file.exists())

        # Verify metadata content
        with open(meta_file, "r", encoding="utf-8") as f:
            meta = json.load(f)

        self.assertEqual(meta["model_architecture"], "XGBoost Regressor")
        self.assertIn("evaluation_metrics", meta)
        self.assertIn("xgboost", meta["evaluation_metrics"])
        self.assertIn("linear_regression_baseline", meta["evaluation_metrics"])

        # Check predictions CSV columns
        pred_df = pd.read_csv(pred_file)
        self.assertIn("battery_id", pred_df.columns)
        self.assertIn("actual_soh", pred_df.columns)
        self.assertIn("predicted_soh", pred_df.columns)
        self.assertIn("absolute_error", pred_df.columns)
        self.assertTrue(len(pred_df) > 0)

    def test_soh_predictor_integration_with_xgboost(self):
        # First train model
        train_soh_pipeline(
            data_path=self.csv_path,
            output_dir=self.output_dir,
            model_dir=self.model_dir,
            random_seed=42
        )

        model_file = self.model_dir / "soh_xgboost.joblib"
        predictor = SOHPredictor(model_path=model_file)

        self.assertEqual(predictor.model_type, "XGBoost Regressor")
        self.assertEqual(predictor.provenance, "Scientific Laboratory Trained")

        # Test single snapshot prediction
        snapshot = {
            "SOC": 80.0,
            "TempMean": 25.0,
            "CellVoltageImbalance": 0.005,
            "PackVoltage": 32.0,
            "PackCurrent": 10.0,
            "PackPower_W": 320.0,
            "Throughput_Ah": 50.0
        }

        soh_pred, attr = predictor.predict_single(snapshot)

        self.assertGreaterEqual(soh_pred, 0.50)
        self.assertLessEqual(soh_pred, 0.99)
        self.assertTrue(len(attr) > 0)

        # Test feature influences diagnostic method
        influences = predictor.get_feature_influences(snapshot)

        self.assertEqual(influences["predicted_soh"], soh_pred)
        self.assertEqual(influences["model_architecture"], "XGBoost Regressor")
        self.assertEqual(influences["provenance"], "Scientific Laboratory Trained")
        self.assertIn("estimation_notice", influences)

    def test_feature_validation_rejection(self):
        model_file = self.model_dir / "soh_xgboost.joblib"
        # Train model first
        train_soh_pipeline(data_path=self.csv_path, output_dir=self.output_dir, model_dir=self.model_dir)

        predictor = SOHPredictor(model_path=model_file, strict_validation=True)
        bad_snapshot = {"SOC": "invalid_string_val"}

        with self.assertRaises(ValueError) as ctx:
            predictor.predict_single(bad_snapshot)

        self.assertIn("Feature validation failed", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
