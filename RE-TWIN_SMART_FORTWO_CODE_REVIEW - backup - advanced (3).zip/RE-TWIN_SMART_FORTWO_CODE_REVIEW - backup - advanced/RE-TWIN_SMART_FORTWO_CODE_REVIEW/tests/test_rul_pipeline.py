"""
Unit and Integration Tests for RUL Training Pipeline and Predictor.
"""

import unittest
import tempfile
import json
from pathlib import Path
import pandas as pd
import numpy as np

from src.ml.rul_data_validation import (
    calculate_rul_target,
    validate_rul_dataset,
    create_rul_group_splits,
    generate_rul_schema_and_readme,
    RULDataValidationError,
    EXPECTED_RUL_OPERATING_FEATURES
)
from src.ml.train_rul import train_rul_pipeline
from src.ml.rul_predictor import RULPredictor, RUL_FEATURES


class TestRULPipeline(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.temp_path = Path(self.temp_dir.name)

        self.data_dir = self.temp_path / "data" / "training"
        self.model_dir = self.temp_path / "models"
        self.output_dir = self.temp_path / "output" / "ml_predictions"
        self.csv_path = self.data_dir / "rul_training.csv"

        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.model_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Generate realistic multi-battery cycling dataset for testing
        records = []
        battery_ids = ["BAT_RUL_01", "BAT_RUL_02", "BAT_RUL_03", "BAT_RUL_04"]
        np.random.seed(42)

        for b_id in battery_ids:
            rated_cap = 50.0
            eol_cycle = 50  # EOL reached at cycle 50
            for cycle in range(51):
                # Capacity drops to 78% by cycle 50
                meas_cap = rated_cap * (1.0 - 0.0044 * cycle)
                records.append({
                    "battery_id": b_id,
                    "cycle_index": cycle,
                    "measured_capacity_ah": round(meas_cap, 4),
                    "rated_capacity_ah": rated_cap,
                    "SOC": round(80.0 - 0.1 * cycle, 2),
                    "TempMean": round(25.0 + 0.05 * cycle, 2),
                    "CellVoltageImbalance": round(0.005 + 0.0005 * cycle, 4),
                    "PackVoltage": round(32.0 - 0.02 * cycle, 2),
                    "PackCurrent": round(10.0 + np.random.normal(0, 0.2), 2),
                    "PackPower_W": round(320.0 + np.random.normal(0, 5), 1),
                    "Throughput_Ah": round(50.0 * (cycle + 1), 2),
                    "eol_cycle": eol_cycle
                })

        self.valid_df = pd.DataFrame(records)
        self.valid_df.to_csv(self.csv_path, index=False)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_rul_target_calculation(self):
        rul_target = calculate_rul_target(self.valid_df)
        self.assertEqual(rul_target.iloc[0], 50)  # 50 - 0 = 50
        self.assertEqual(rul_target.iloc[50], 0)  # 50 - 50 = 0
        self.assertTrue((rul_target >= 0).all())

    def test_eol_threshold_derivation(self):
        df_no_eol = self.valid_df.drop(columns=["eol_cycle"])
        rul_target = calculate_rul_target(df_no_eol, eol_threshold_pct=80.0)
        self.assertTrue(len(rul_target) == len(self.valid_df))
        self.assertGreaterEqual(rul_target.iloc[0], 40)

    def test_configurable_eol_threshold(self):
        df_no_eol = self.valid_df.drop(columns=["eol_cycle"])
        # EOL threshold at 80% capacity retention
        rul_80 = calculate_rul_target(df_no_eol, eol_threshold_pct=80.0)
        # EOL threshold at 70% capacity retention (takes longer to reach 70%)
        rul_70 = calculate_rul_target(df_no_eol, eol_threshold_pct=70.0)

        # RUL to 70% threshold must be greater than or equal to RUL to 80% threshold
        self.assertGreaterEqual(rul_70.iloc[0], rul_80.iloc[0])

    def test_validate_rul_dataset_detects_data_leakage(self):
        bad_df = self.valid_df.copy()
        with self.assertRaises(RULDataValidationError) as ctx:
            validate_rul_dataset(bad_df, operating_features=EXPECTED_RUL_OPERATING_FEATURES + ["eol_cycle"])
        self.assertIn("data leakage detected", str(ctx.exception).lower())

    def test_create_rul_group_splits_no_leakage(self):
        validated_df, _ = validate_rul_dataset(self.valid_df)
        splits = create_rul_group_splits(
            validated_df,
            feature_cols=EXPECTED_RUL_OPERATING_FEATURES,
            target_col="rul_target_cycles",
            battery_id_col="battery_id",
            test_size=0.25,
            random_state=42
        )

        train_groups = set(splits["train_groups"])
        test_groups = set(splits["test_groups"])

        self.assertEqual(len(train_groups.intersection(test_groups)), 0)
        self.assertTrue(len(splits["X_train"]) > 0)
        self.assertTrue(len(splits["X_test"]) > 0)

    def test_missing_dataset_handling(self):
        missing_csv = self.temp_path / "missing" / "rul_training.csv"
        result = train_rul_pipeline(
            data_path=missing_csv,
            output_dir=self.output_dir,
            model_dir=self.model_dir
        )

        self.assertEqual(result["status"], "MISSING_DATASET")
        self.assertTrue(Path(result["readme_path"]).exists())
        self.assertTrue(Path(result["schema_path"]).exists())

    def test_full_rul_pipeline_execution_and_artifacts(self):
        result = train_rul_pipeline(
            data_path=self.csv_path,
            output_dir=self.output_dir,
            model_dir=self.model_dir,
            random_seed=42
        )

        self.assertEqual(result["status"], "SUCCESS")

        model_file = self.model_dir / "rul_random_forest.joblib"
        meta_file = self.model_dir / "rul_random_forest_metadata.json"
        eval_file = self.output_dir / "rul_evaluation.json"
        pred_file = self.output_dir / "rul_predictions.csv"

        self.assertTrue(model_file.exists())
        self.assertTrue(meta_file.exists())
        self.assertTrue(eval_file.exists())
        self.assertTrue(pred_file.exists())

        # Check metadata
        with open(meta_file, "r", encoding="utf-8") as f:
            meta = json.load(f)

        self.assertEqual(meta["model_architecture"], "Random Forest Regressor")
        self.assertEqual(meta["rul_unit"], "Cycles remaining")
        self.assertIn("evaluation_metrics", meta)

        # Check predictions CSV columns
        pred_df = pd.read_csv(pred_file)
        self.assertIn("battery_id", pred_df.columns)
        self.assertIn("current_cycle", pred_df.columns)
        self.assertIn("actual_rul", pred_df.columns)
        self.assertIn("predicted_rul", pred_df.columns)
        self.assertIn("absolute_error", pred_df.columns)

    def test_rul_predictor_integration(self):
        train_rul_pipeline(
            data_path=self.csv_path,
            output_dir=self.output_dir,
            model_dir=self.model_dir,
            random_seed=42
        )

        model_file = self.model_dir / "rul_random_forest.joblib"
        predictor = RULPredictor(model_path=model_file)

        self.assertEqual(predictor.model_type, "Random Forest Regressor")
        self.assertEqual(predictor.rul_unit, "Cycles remaining")

        snapshot = {
            "SOC": 80.0,
            "TempMean": 25.0,
            "CellVoltageImbalance": 0.005,
            "PackVoltage": 32.0,
            "PackCurrent": 10.0,
            "PackPower_W": 320.0,
            "Throughput_Ah": 50.0,
            "cycle_index": 0
        }

        rul_pred, diag = predictor.predict_single(snapshot)

        self.assertGreaterEqual(rul_pred, 0.0)
        self.assertEqual(diag["rul_unit"], "Cycles remaining")
        self.assertEqual(diag["estimation_notice"], "MODEL ESTIMATE (Machine Learning RUL Prediction)")
        self.assertIn("feature_importances", diag)

    def test_rul_feature_validation_rejection(self):
        model_file = self.model_dir / "rul_random_forest.joblib"
        train_rul_pipeline(data_path=self.csv_path, output_dir=self.output_dir, model_dir=self.model_dir)

        predictor = RULPredictor(model_path=model_file, strict_validation=True)
        bad_snapshot = {"SOC": "invalid_val"}

        with self.assertRaises(ValueError) as ctx:
            predictor.predict_single(bad_snapshot)

        self.assertIn("Feature validation failed", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
