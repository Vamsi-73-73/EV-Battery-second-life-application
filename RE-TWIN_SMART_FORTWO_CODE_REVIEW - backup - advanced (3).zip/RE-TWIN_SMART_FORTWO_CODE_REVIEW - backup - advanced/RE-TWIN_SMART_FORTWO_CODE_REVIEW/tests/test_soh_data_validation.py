"""
Unit tests for SOH Data Validation & Preparation Pipeline.
"""

import unittest
import tempfile
from pathlib import Path
import pandas as pd
import numpy as np

from src.ml.data_validation import (
    calculate_soh,
    validate_soh_dataset,
    create_group_splits,
    generate_dataset_schema_and_readme,
    DataValidationError,
    EXPECTED_OPERATING_FEATURES
)


class TestSOHDataValidation(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.temp_path = Path(self.temp_dir.name)

        # Create valid mock dataframe with 3 battery packs
        records = []
        battery_ids = ["BAT_PACK_01", "BAT_PACK_02", "BAT_PACK_03"]
        for b_id in battery_ids:
            rated_cap = 50.0
            for cycle in range(10):
                # Capacity degrades over cycles
                meas_cap = rated_cap * (1.0 - 0.005 * cycle)
                records.append({
                    "battery_id": b_id,
                    "cycle_index": cycle,
                    "measured_capacity_ah": meas_cap,
                    "rated_capacity_ah": rated_cap,
                    "SOC": 80.0 - 0.5 * cycle,
                    "TempMean": 25.0 + 0.2 * cycle,
                    "CellVoltageImbalance": 0.005 + 0.001 * cycle,
                    "PackVoltage": 32.0 - 0.1 * cycle,
                    "PackCurrent": 10.0,
                    "PackPower_W": 320.0,
                    "Throughput_Ah": 50.0 * (cycle + 1)
                })
        self.valid_df = pd.DataFrame(records)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_calculate_soh_from_capacity(self):
        soh_pct, soh_ratio = calculate_soh(self.valid_df)
        self.assertAlmostEqual(soh_pct.iloc[0], 100.0, places=2)
        self.assertAlmostEqual(soh_ratio.iloc[0], 1.0, places=4)
        # Verify degraded cycle SOH
        self.assertAlmostEqual(soh_pct.iloc[9], 95.5, places=2)
        self.assertAlmostEqual(soh_ratio.iloc[9], 0.955, places=4)

    def test_calculate_soh_invalid_capacity(self):
        bad_df = self.valid_df.copy()
        bad_df.loc[0, "rated_capacity_ah"] = 0.0
        with self.assertRaises(DataValidationError):
            calculate_soh(bad_df)

    def test_validate_soh_dataset_clean(self):
        validated_df, report = validate_soh_dataset(self.valid_df)
        self.assertEqual(report["total_input_rows"], 30)
        self.assertEqual(report["validated_output_rows"], 30)
        self.assertEqual(len(report["battery_ids_found"]), 3)
        self.assertIn("soh_target_pct", validated_df.columns)
        self.assertIn("soh_target_ratio", validated_df.columns)

    def test_validate_soh_dataset_detects_missing_features(self):
        bad_df = self.valid_df.drop(columns=["TempMean"])
        with self.assertRaises(DataValidationError) as ctx:
            validate_soh_dataset(bad_df)
        self.assertIn("missing required operating features", str(ctx.exception).lower())

    def test_validate_soh_dataset_removes_duplicates(self):
        dup_df = pd.concat([self.valid_df, self.valid_df.iloc[:3]], ignore_index=True)
        validated_df, report = validate_soh_dataset(dup_df)
        self.assertEqual(report["duplicate_rows_removed"], 3)
        self.assertEqual(len(validated_df), 30)

    def test_validate_soh_dataset_detects_data_leakage(self):
        leak_df = self.valid_df.copy()

        # Passing a target variable in feature list should raise DataValidationError
        with self.assertRaises(DataValidationError) as ctx:
            validate_soh_dataset(leak_df, operating_features=EXPECTED_OPERATING_FEATURES + ["measured_capacity_ah"])
        self.assertIn("data leakage detected", str(ctx.exception).lower())

    def test_create_group_splits_no_leakage(self):
        validated_df, _ = validate_soh_dataset(self.valid_df)
        splits = create_group_splits(
            validated_df,
            feature_cols=EXPECTED_OPERATING_FEATURES,
            target_col="soh_target_ratio",
            battery_id_col="battery_id",
            test_size=0.33,
            random_state=42
        )

        train_groups = set(splits["train_groups"])
        test_groups = set(splits["test_groups"])

        # Group-based split must ensure zero overlap between train and test battery IDs
        self.assertEqual(len(train_groups.intersection(test_groups)), 0)
        self.assertTrue(len(splits["X_train"]) > 0)
        self.assertTrue(len(splits["X_test"]) > 0)

    def test_generate_dataset_schema_and_readme(self):
        out_dir = self.temp_path / "training"
        schema_path, readme_path = generate_dataset_schema_and_readme(out_dir)

        self.assertTrue(schema_path.exists())
        self.assertTrue(readme_path.exists())
        self.assertIn("README.md", readme_path.name)
        self.assertIn("schema.json", schema_path.name)


if __name__ == "__main__":
    unittest.main()
