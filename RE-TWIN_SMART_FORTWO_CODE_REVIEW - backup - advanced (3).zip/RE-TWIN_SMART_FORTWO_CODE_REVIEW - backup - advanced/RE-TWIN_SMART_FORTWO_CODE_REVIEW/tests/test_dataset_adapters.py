"""
Unit and integration tests for dataset adapters, registries, schema validation,
and SOH/RUL pipeline data preparation.
"""

from pathlib import Path
import pytest
import pandas as pd
import numpy as np

from src.ml.data.dataset_registry import (
    DATASET_REGISTRY,
    get_dataset_info,
    get_supported_datasets,
    validate_dataset_compatibility
)
from src.ml.data.dataset_validation import (
    validate_battery_aging_df,
    validate_soh_target_schema,
    validate_rul_target_schema
)
from src.ml.data.nasa_adapter import NASAAdapter
from src.ml.data.oxford_adapter import OxfordAdapter
from src.ml.data.calce_adapter import CALCEAdapter
from src.ml.data.prepare_soh_data import prepare_soh_dataset
from src.ml.data.prepare_rul_data import prepare_rul_dataset


def test_dataset_registry():
    """Verify registry metadata for NASA, Oxford, and CALCE."""
    supported = get_supported_datasets()
    assert "NASA_PCOE" in supported
    assert "OXFORD_DEGRADATION" in supported
    assert "CALCE_DEGRADATION" in supported

    nasa_info = get_dataset_info("NASA_PCOE")
    assert nasa_info is not None
    assert nasa_info.chemistry == "NCA / LiCoO2"
    assert nasa_info.rated_capacity_ah == 2.0
    assert nasa_info.eol_capacity_threshold_ah == 1.4

    compat = validate_dataset_compatibility("NASA_PCOE", "Smart fortwo 451 ED")
    assert compat["chem_match"] is False
    assert len(compat["limitations"]) > 0


def test_dataset_validation_soh():
    """Test raw validation and SOH target calculation."""
    df_raw = pd.DataFrame({
        "battery_id": ["B0005", "B0005", "B0005"],
        "cycle_index": [1, 2, 3],
        "measured_capacity_ah": [2.0, 1.9, 1.8],
        "rated_capacity_ah": [2.0, 2.0, 2.0]
    })

    clean_df, report = validate_soh_target_schema(df_raw)
    assert len(clean_df) == 3
    assert "soh_target_pct" in clean_df.columns
    np.testing.assert_allclose(clean_df["soh_target_pct"].values, [100.0, 95.0, 90.0])
    assert report["clean_rows"] == 3


def test_dataset_validation_rul():
    """Test RUL target calculation formula: RUL = EOL cycle - Current cycle."""
    df_raw = pd.DataFrame({
        "battery_id": ["B0005", "B0005", "B0005"],
        "cycle_index": [1, 2, 3],
        "measured_capacity_ah": [2.0, 1.9, 1.4],
        "rated_capacity_ah": [2.0, 2.0, 2.0]
    })

    clean_df, report = validate_rul_target_schema(df_raw, eol_capacity_threshold_ah=1.4)
    assert len(clean_df) == 3
    assert "rul_target_cycles" in clean_df.columns
    # EOL cycle is cycle 3 (1.4 Ah) -> RUL = [3-1, 3-2, 3-3] = [2, 1, 0]
    np.testing.assert_array_equal(clean_df["rul_target_cycles"].values, [2, 1, 0])


def test_nasa_adapter_mock(tmp_path):
    """Test NASA adapter parsing with synthetic CSV data matching expected NASA structure."""
    nasa_dir = tmp_path / "nasa"
    nasa_dir.mkdir()
    
    df_nasa = pd.DataFrame({
        "battery_id": ["B0005"] * 5,
        "cycle": [1, 2, 3, 4, 5],
        "capacity": [1.85, 1.82, 1.80, 1.75, 1.40],
        "temperature": [24.0] * 5,
        "voltage_measured": [4.2] * 5,
        "current_measured": [-2.0] * 5
    })
    df_nasa.to_csv(nasa_dir / "b0005.csv", index=False)

    adapter = NASAAdapter(nasa_dir)
    assert adapter.is_dataset_available() is True
    
    df_soh, report_soh = adapter.extract_soh_dataset()
    assert len(df_soh) == 5
    assert "soh_percent" in df_soh.columns or "soh_target_pct" in df_soh.columns or "measured_capacity_ah" in df_soh.columns

    df_rul, report_rul = adapter.extract_rul_dataset()
    assert len(df_rul) == 5


def test_oxford_adapter_mock(tmp_path):
    """Test Oxford adapter parsing with synthetic CSV data."""
    oxford_dir = tmp_path / "oxford"
    oxford_dir.mkdir()

    df_oxford = pd.DataFrame({
        "cell_id": ["Cell1"] * 5,
        "cycle": [1, 2, 3, 4, 5],
        "capacity_ah": [0.74, 0.73, 0.72, 0.70, 0.59],
        "temperature_c": [40.0] * 5
    })
    df_oxford.to_csv(oxford_dir / "oxford_cell1.csv", index=False)

    adapter = OxfordAdapter(oxford_dir)
    assert adapter.is_dataset_available() is True

    df_soh, report = adapter.extract_soh_dataset()
    assert len(df_soh) == 5


def test_calce_adapter_mock(tmp_path):
    """Test CALCE adapter parsing with synthetic CSV data."""
    calce_dir = tmp_path / "calce"
    calce_dir.mkdir()

    df_calce = pd.DataFrame({
        "cell_id": ["CS2_35"] * 5,
        "cycle_index": [1, 2, 3, 4, 5],
        "discharge_capacity_ah": [1.10, 1.08, 1.05, 1.00, 0.88],
        "temperature_c": [25.0] * 5
    })
    df_calce.to_csv(calce_dir / "calce_cs2_35.csv", index=False)

    adapter = CALCEAdapter(calce_dir)
    assert adapter.is_dataset_available() is True

    df_soh, report = adapter.extract_soh_dataset()
    assert len(df_soh) == 5


def test_prepare_soh_and_rul_datasets_empty(tmp_path):
    """Verify gracefully handling missing raw dataset directory."""
    empty_raw = tmp_path / "raw"
    empty_raw.mkdir()

    res_soh = prepare_soh_dataset(raw_dir=empty_raw, output_csv=tmp_path / "soh.csv")
    assert res_soh["status"] == "DATA_UNAVAILABLE"
    assert not (tmp_path / "soh.csv").exists()

    res_rul = prepare_rul_dataset(raw_dir=empty_raw, output_csv=tmp_path / "rul.csv")
    assert res_rul["status"] == "DATA_UNAVAILABLE"
    assert not (tmp_path / "rul.csv").exists()
