import re

with open('dashboard.html', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'id=' in line and ('view' in line or 'health' in line or 'risk' in line):
        print(f"Line {idx+1}: {line.strip()}")
