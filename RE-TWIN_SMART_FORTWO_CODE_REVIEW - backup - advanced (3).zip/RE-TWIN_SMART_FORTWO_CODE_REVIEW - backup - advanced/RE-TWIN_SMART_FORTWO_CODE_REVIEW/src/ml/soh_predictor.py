"""
Machine Learning Module for SOH Prediction.

Supports both interpretable Linear Regression baseline and scientific XGBoost Regressor.
Enforces strict feature schema validation, reports model provenance and versioning,
and clearly labels predictions as model estimates.
"""

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Union
import json
import numpy as np
import pandas as pd
import joblib
from sklearn.linear_model import LinearRegression

FEATURES = [
    "SOC",
    "TempMean",
    "CellVoltageImbalance",
    "PackVoltage",
    "PackCurrent",
    "PackPower_W",
    "Throughput_Ah"
]


class SOHPredictor:
    def __init__(self, model_path: Optional[Union[str, Path]] = None, strict_validation: bool = False):
        self.model: Any = None
        self.imputer: Any = None
        self.scaler: Any = None
        self.feature_names: List[str] = FEATURES.copy()
        self.model_type: str = "Linear Regression (Baseline)"
        self.provenance: str = "Physics-Inspired Demonstration Baseline"
        self.model_version: str = "1.0.0"
        self.strict_validation: bool = strict_validation
        self.model_path: Optional[Path] = Path(model_path) if model_path else None
        
        if self.model_path and self.model_path.exists():
            self.load(self.model_path)

    def load(self, path: Path):
        """
        Loads a serialized model artifact (LinearRegression or XGBoost pipeline artifact).
        """
        self.model_path = Path(path)
        artifact = joblib.load(self.model_path)

        if isinstance(artifact, dict) and "model" in artifact:
            # XGBoost Pipeline artifact container
            self.model = artifact["model"]
            self.imputer = artifact.get("imputer")
            self.scaler = artifact.get("scaler")
            self.feature_names = artifact.get("feature_names", FEATURES)
            self.model_type = artifact.get("model_type", "XGBoost Regressor")
            self.provenance = "Scientific Laboratory Trained"

            # Check if metadata file exists adjacent to model
            meta_path = self.model_path.with_name("soh_xgboost_metadata.json")
            if meta_path.exists():
                try:
                    with open(meta_path, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                        self.model_version = meta.get("model_version", "1.0.0")
                        self.provenance = meta.get("provenance", self.provenance)
                except Exception:
                    pass
        else:
            # Standalone Linear Regression object
            self.model = artifact
            self.imputer = None
            self.scaler = None
            self.model_type = "Linear Regression"
            self.provenance = "Interpretable Linear Regression (CAN Features)"

    def save(self, path: Path):
        """Saves current model to disk."""
        path.parent.mkdir(parents=True, exist_ok=True)
        if self.scaler or self.imputer:
            artifact = {
                "imputer": self.imputer,
                "scaler": self.scaler,
                "model": self.model,
                "feature_names": self.feature_names,
                "model_type": self.model_type
            }
            joblib.dump(artifact, path)
        else:
            joblib.dump(self.model, path)

    def validate_input_features(self, snapshot_dict: Dict[str, Any]) -> Tuple[bool, List[str], List[str]]:
        """
        Validates input feature dict against saved feature schema.

        Returns:
            is_valid: bool
            missing_features: List[str]
            incompatible_features: List[str]
        """
        missing = []
        incompatible = []

        for f in self.feature_names:
            val = snapshot_dict.get(f)
            if val is None:
                missing.append(f)
            else:
                try:
                    float_val = float(val)
                    if np.isnan(float_val) or np.isinf(float_val):
                        incompatible.append(f"{f} (NaN/Inf)")
                except (ValueError, TypeError):
                    incompatible.append(f"{f} (non-numeric)")

        is_valid = (len(missing) == 0) and (len(incompatible) == 0)
        return is_valid, missing, incompatible

    def get_model_info(self) -> Dict[str, Any]:
        """Returns model versioning, architecture, and provenance metadata."""
        return {
            "model_version": self.model_version,
            "model_architecture": self.model_type,
            "provenance": self.provenance,
            "estimation_notice": "MODEL ESTIMATE (Non-causal Machine Learning Prediction)",
            "feature_schema": self.feature_names,
            "is_loaded": self.model is not None
        }

    def train_on_features(self, df: pd.DataFrame) -> Dict[str, float]:
        """
        Trains baseline Linear Regression model on extracted feature set.
        Kept for backward compatibility.
        """
        from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
        from sklearn.model_selection import train_test_split

        df_copy = df.copy()
        throughput = df_copy["Throughput_Ah"].fillna(0) if "Throughput_Ah" in df_copy.columns else (df_copy["PackCurrent"].abs() * 0.1 / 3600.0).cumsum()
        imbalance = df_copy["CellVoltageImbalance"].fillna(0.005) if "CellVoltageImbalance" in df_copy.columns else pd.Series([0.005]*len(df_copy))
        temp = df_copy["TempMean"].fillna(25.0) if "TempMean" in df_copy.columns else pd.Series([25.0]*len(df_copy))
        soc = df_copy["SOC"].fillna(80.0) if "SOC" in df_copy.columns else pd.Series([80.0]*len(df_copy))

        y = (
            0.8860
            - 0.0020 * throughput
            - 0.12 * imbalance.clip(lower=0)
            - 0.0004 * (temp - 25.0).clip(lower=0)
            - 0.0005 * (1.0 - soc / 100.0)
        ).clip(0.60, 0.98)

        avail = [f for f in self.feature_names if f in df_copy.columns]
        X = df_copy[avail].replace([np.inf, -np.inf], np.nan).ffill().bfill().fillna(0)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        self.model = LinearRegression().fit(X_train, y_train)

        test_preds = self.model.predict(X_test)
        return {
            "mae": float(mean_absolute_error(y_test, test_preds)),
            "rmse": float(np.sqrt(mean_squared_error(y_test, test_preds))),
            "r2": float(r2_score(y_test, test_preds))
        }

    def predict_single(self, snapshot_dict: Dict[str, Any]) -> Tuple[float, Dict[str, float]]:
        """
        Predicts SOH for a single telemetry snapshot frame.

        Enforces input feature validation, preprocessing, and output clamping [0.50, 0.99].
        """
        is_valid, missing, incompatible = self.validate_input_features(snapshot_dict)
        if not is_valid and self.strict_validation:
            raise ValueError(
                f"Feature validation failed for SOH predictor! Missing: {missing}, Incompatible: {incompatible}"
            )

        if self.model is None:
            # Safe default fallback if model is not loaded
            return 0.88, {"baseline": 0.88}

        row = {f: float(snapshot_dict.get(f, 0.0) or 0.0) for f in self.feature_names}
        X_df = pd.DataFrame([row])

        # Apply fitted preprocessing if present
        if self.imputer is not None:
            X_prep = self.imputer.transform(X_df)
        else:
            X_prep = X_df

        if self.scaler is not None:
            X_prep = self.scaler.transform(X_prep)

        pred = float(self.model.predict(X_prep)[0])
        pred_clamped = float(max(0.50, min(0.99, pred)))

        # Explainable attribution breakdown
        attribution: Dict[str, float] = {}
        if hasattr(self.model, "coef_") and hasattr(self.model, "intercept_"):
            attribution["intercept"] = round(float(self.model.intercept_), 4)
            for name, coef, val in zip(self.feature_names, self.model.coef_, X_df.iloc[0]):
                attribution[name] = round(float(coef * val), 5)
        elif hasattr(self.model, "feature_importances_"):
            for name, imp in zip(self.feature_names, self.model.feature_importances_):
                attribution[name] = round(float(imp), 5)

        return round(pred_clamped, 4), attribution

    def predict_dataframe(self, df: pd.DataFrame) -> pd.Series:
        """
        Runs batch inference across DataFrame with robust imputation and preprocessing.
        """
        if self.model is None:
            return pd.Series([0.88] * len(df))

        X = df.copy()
        for f in self.feature_names:
            if f not in X.columns:
                X[f] = 0.0

        X = X[self.feature_names].replace([np.inf, -np.inf], np.nan)

        if self.imputer is not None:
            X_prep = self.imputer.transform(X)
        else:
            X_prep = X.ffill().bfill().fillna(0)

        if self.scaler is not None:
            X_prep = self.scaler.transform(X_prep)

        preds = self.model.predict(X_prep)
        return pd.Series(np.clip(preds, 0.50, 0.99)).round(4)

    def get_feature_influences(self, snapshot_dict: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculates feature attributions and returns structured diagnostic info.
        """
        soh_pred, raw_attribution = self.predict_single(snapshot_dict)
        influences = []

        if hasattr(self.model, "coef_") and hasattr(self.model, "intercept_"):
            intercept = float(self.model.intercept_)
            for name, coef in zip(self.feature_names, self.model.coef_):
                val = float(snapshot_dict.get(name, 0.0) or 0.0)
                contribution = float(coef * val)
                influences.append({
                    "feature_name": name,
                    "input_value": round(val, 4),
                    "model_coefficient": round(float(coef), 6),
                    "model_contribution": round(contribution, 6),
                    "influence_direction": "DEGRADATION_PENALTY" if contribution < 0 else "BASELINE_PRESERVATION",
                    "description": f"Linear model contribution of {name} to SOH estimate"
                })
        elif hasattr(self.model, "feature_importances_"):
            intercept = 0.0
            for name, imp in zip(self.feature_names, self.model.feature_importances_):
                val = float(snapshot_dict.get(name, 0.0) or 0.0)
                influences.append({
                    "feature_name": name,
                    "input_value": round(val, 4),
                    "feature_importance": round(float(imp), 6),
                    "model_contribution": round(float(imp * val), 6),
                    "influence_direction": "TREE_SPLIT_IMPORTANCE",
                    "description": f"XGBoost feature importance of {name}"
                })
        else:
            intercept = 0.88

        influences.sort(key=lambda x: abs(x.get("model_contribution", 0.0)), reverse=True)

        return {
            "predicted_soh": soh_pred,
            "predicted_soh_pct": round(soh_pred * 100.0, 2),
            "model_version": self.model_version,
            "model_architecture": self.model_type,
            "provenance": self.provenance,
            "estimation_notice": "MODEL ESTIMATE (Non-causal Machine Learning Prediction)",
            "feature_influences": influences,
            "scientific_disclaimer": (
                "Feature influences represent mathematical model attributions. "
                "They do not establish direct electrochemical causality. "
                "Laboratory cycler validation is required for certified deployment."
            )
        }
