"""
Reusable Prediction Interface for Smart fortwo Operational Anomaly Detection using Isolation Forest.

Loads serialized Isolation Forest pipeline artifact, validates incoming telemetry features against
the verified Smart fortwo schema, calculates decision function anomaly scores, flags anomalous states,
and reports contamination parameters and probability disclaimers.
"""

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Union
import json
import numpy as np
import pandas as pd
import joblib

ANOMALY_FEATURES = [
    "SOC",
    "charging_current_limit_command",
    "charging_current_limit_reply",
    "charge_current_a"
]


class AnomalyDetector:
    def __init__(self, model_path: Optional[Union[str, Path]] = None, strict_validation: bool = False):
        self.model: Any = None
        self.imputer: Any = None
        self.scaler: Any = None
        self.feature_names: List[str] = ANOMALY_FEATURES.copy()
        self.model_type: str = "Isolation Forest"
        self.contamination: float = 0.05
        self.provenance: str = "Smart fortwo Real OBD/CAN Capture (Jun 2018)"
        self.operating_context: str = "Level 2 AC Charging (94.2% to 100% SOC)"
        self.model_version: str = "1.0.0"
        self.strict_validation: bool = strict_validation
        self.model_path: Optional[Path] = Path(model_path) if model_path else None

        if self.model_path and self.model_path.exists():
            self.load(self.model_path)

    def load(self, path: Path):
        """
        Loads serialized Isolation Forest pipeline artifact container.
        """
        self.model_path = Path(path)
        artifact = joblib.load(self.model_path)

        if isinstance(artifact, dict) and "model" in artifact:
            self.model = artifact["model"]
            self.imputer = artifact.get("imputer")
            self.scaler = artifact.get("scaler")
            self.feature_names = artifact.get("feature_names", ANOMALY_FEATURES)
            self.model_type = artifact.get("model_type", "Isolation Forest")
            self.contamination = artifact.get("contamination", 0.05)
            self.provenance = "Smart fortwo Real OBD/CAN Capture (Jun 2018)"

            meta_path = self.model_path.with_name("anomaly_isolation_forest_metadata.json")
            if meta_path.exists():
                try:
                    with open(meta_path, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                        self.model_version = meta.get("model_version", "1.0.0")
                        self.provenance = meta.get("provenance", self.provenance)
                        self.operating_context = meta.get("operating_context", self.operating_context)
                except Exception:
                    pass
        else:
            self.model = artifact
            self.imputer = None
            self.scaler = None
            self.model_type = "Isolation Forest"

    def validate_input_features(self, snapshot_dict: Dict[str, Any]) -> Tuple[bool, List[str], List[str]]:
        """
        Validates input feature dict against saved anomaly feature schema.

        Returns:
            is_valid: bool
            missing_features: List[str]
            incompatible_features: List[str]
        """
        missing = []
        incompatible = []

        for f in self.feature_names:
            val = snapshot_dict.get(f)
            if val is None:
                missing.append(f)
            else:
                try:
                    float_val = float(val)
                    if np.isnan(float_val) or np.isinf(float_val):
                        incompatible.append(f"{f} (NaN/Inf)")
                except (ValueError, TypeError):
                    incompatible.append(f"{f} (non-numeric)")

        is_valid = (len(missing) == 0) and (len(incompatible) == 0)
        return is_valid, missing, incompatible

    def get_model_info(self) -> Dict[str, Any]:
        """Returns anomaly detector version, architecture, provenance, contamination parameter, and probability disclaimers."""
        return {
            "model_version": self.model_version,
            "model_architecture": self.model_type,
            "contamination_parameter": self.contamination,
            "contamination_notice": (
                "The contamination parameter represents an assumed expected anomaly fraction "
                "within the training set, NOT a ground-truth measured anomaly rate."
            ),
            "provenance": self.provenance,
            "operating_context": self.operating_context,
            "thresholding_method": "Decision function threshold offset at 0.0 (decision_function score < 0.0 is anomalous)",
            "probability_disclaimer": (
                "Anomaly scores represent tree isolation path length offsets. "
                "They are NOT calibrated statistical probabilities of failure."
            ),
            "feature_schema": self.feature_names,
            "is_loaded": self.model is not None
        }

    def predict_single(self, snapshot_dict: Dict[str, Any]) -> Tuple[float, bool, Dict[str, Any]]:
        """
        Evaluates operational anomaly score and flag for a single telemetry snapshot.

        Returns:
            anomaly_score: float (inverted decision_function score, higher = more anomalous)
            is_anomaly: bool (True if anomalous, False if normal)
            diagnostic_dict: Dict containing score breakdown, flags, and disclaimers.
        """
        is_valid, missing, incompatible = self.validate_input_features(snapshot_dict)
        if not is_valid and self.strict_validation:
            raise ValueError(
                f"Feature validation failed for Anomaly detector! Missing: {missing}, Incompatible: {incompatible}"
            )

        if self.model is None:
            return 0.0, False, {
                "anomaly_flag": "NORMAL",
                "model_version": self.model_version,
                "notice": "UNLOADED_MODEL_DEFAULT"
            }

        row = {f: float(snapshot_dict.get(f, 0.0) or 0.0) for f in self.feature_names}
        X_df = pd.DataFrame([row])

        if self.imputer is not None:
            X_prep = self.imputer.transform(X_df)
        else:
            X_prep = X_df

        if self.scaler is not None:
            X_prep = self.scaler.transform(X_prep)
            X_prep = pd.DataFrame(X_prep, columns=self.feature_names)

        dec_score = float(self.model.decision_function(X_prep)[0])
        pred_flag = int(self.model.predict(X_prep)[0])

        anomaly_score = float(round(-dec_score, 4))
        is_anomaly = bool(pred_flag == -1)

        diagnostics = {
            "anomaly_score": anomaly_score,
            "decision_function_raw": round(dec_score, 4),
            "is_anomaly": is_anomaly,
            "anomaly_flag": "ANOMALOUS" if is_anomaly else "NORMAL",
            "model_version": self.model_version,
            "model_architecture": self.model_type,
            "contamination_parameter": self.contamination,
            "operating_context": self.operating_context,
            "provenance": self.provenance,
            "probability_disclaimer": (
                "Anomaly score represents Isolation Forest path length offset. "
                "It is NOT a calibrated probability."
            )
        }

        return anomaly_score, is_anomaly, diagnostics

    def predict_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Runs batch anomaly inference across DataFrame.
        Returns DataFrame with 'anomaly_score' and 'anomaly_flag' columns.
        """
        if self.model is None:
            res = df.copy()
            res["anomaly_score"] = 0.0
            res["anomaly_flag"] = "NORMAL"
            return res

        X = df.copy()
        for f in self.feature_names:
            if f not in X.columns:
                X[f] = 0.0

        X = X[self.feature_names].replace([np.inf, -np.inf], np.nan)

        if self.imputer is not None:
            X_prep = self.imputer.transform(X)
        else:
            X_prep = X.ffill().bfill().fillna(0)

        if self.scaler is not None:
            X_prep = self.scaler.transform(X_prep)
            X_prep = pd.DataFrame(X_prep, columns=self.feature_names)

        dec_scores = self.model.decision_function(X_prep)
        pred_flags = self.model.predict(X_prep)

        res_df = df.copy()
        res_df["anomaly_score"] = np.round(-dec_scores, 4)
        res_df["anomaly_flag"] = ["ANOMALOUS" if f == -1 else "NORMAL" for f in pred_flags]
        return res_df
