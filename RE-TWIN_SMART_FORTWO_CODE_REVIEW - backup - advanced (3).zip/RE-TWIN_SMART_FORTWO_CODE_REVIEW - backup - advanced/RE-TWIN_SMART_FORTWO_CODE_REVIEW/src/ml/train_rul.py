"""
Scientifically Valid Battery Remaining Useful Life (RUL) Training Pipeline using Random Forest Regressor.

Reads real battery aging data from data/training/rul_training.csv, calculates RUL target (EOL cycle - Current cycle),
performs group-based train/test splitting by battery identifier, fits preprocessing strictly on training data,
trains RandomForestRegressor, evaluates MAE and RMSE on held-out test split, and serializes model artifacts.
"""

from pathlib import Path
import sys
import json
from typing import Optional, Dict, Any, List, Tuple
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Add project root to sys.path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from src.ml.rul_data_validation import (
    validate_rul_dataset,
    create_rul_group_splits,
    generate_rul_schema_and_readme,
    EXPECTED_RUL_OPERATING_FEATURES,
    RUL_FEATURE_UNITS,
    RULDataValidationError
)


def train_rul_pipeline(
    data_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
    model_dir: Optional[Path] = None,
    random_seed: int = 42,
    eol_threshold_pct: float = 80.0
) -> Dict[str, Any]:
    """
    Executes the RUL model training pipeline.

    Args:
        data_path: Path to input training CSV (default: data/training/rul_training.csv).
        output_dir: Path to directory for prediction/evaluation outputs (default: output/ml_predictions).
        model_dir: Path to directory for model artifacts (default: models).
        random_seed: Reproducible random seed.

    Returns:
        Dictionary summary of training results and evaluation metrics.
    """
    if data_path is None:
        data_path = ROOT / "data" / "training" / "rul_training.csv"
    if output_dir is None:
        output_dir = ROOT / "output" / "ml_predictions"
    if model_dir is None:
        model_dir = ROOT / "models"

    training_dir = data_path.parent

    print("=" * 75)
    print("  RE-TWIN: Battery RUL Model Training Pipeline (Random Forest)")
    print("=" * 75)

    # 1. Check if required dataset exists
    if not data_path.exists():
        print(f"\n[STATUS] RUL training dataset missing at expected location: {data_path}")
        schema_file, readme_file = generate_rul_schema_and_readme(training_dir)
        print(f"[ACTION] Generated RUL dataset schema and README:")
        print(f"  - Schema: {schema_file}")
        print(f"  - README: {readme_file}")
        print("\n[EXPLANATION OF MISSING DATA]")
        print("  - Real laboratory battery degradation cycler test data (e.g. NASA, CALCE, Oxford, OEM) is required.")
        print("  - Dataset must contain degradation cycle indexes and measured discharge capacity down to EOL (80% SOH).")
        print("  - Synthetic Smart fortwo demonstration telemetry must NEVER be used as real aging data.")
        print("  - Please populate data/training/rul_training.csv according to data/training/README_RUL.md to train.")
        print("=" * 75)
        return {
            "status": "MISSING_DATASET",
            "message": f"RUL training dataset missing at {data_path}. Schema and README generated.",
            "data_path": str(data_path),
            "readme_path": str(readme_file),
            "schema_path": str(schema_file)
        }

    # 2. Load and Validate Dataset
    print(f"\n[1/5] Loading and validating RUL dataset from: {data_path.name}")
    raw_df = pd.read_csv(data_path)
    validated_df, val_report = validate_rul_dataset(
        raw_df,
        operating_features=EXPECTED_RUL_OPERATING_FEATURES,
        eol_threshold_pct=eol_threshold_pct
    )
    print(f"  - Input rows: {val_report['total_input_rows']}, Validated rows: {val_report['validated_output_rows']}")
    print(f"  - Unique Battery IDs: {val_report['battery_ids_found']}")

    if val_report["warnings"]:
        for w in val_report["warnings"]:
            print(f"  - Warning: {w}")

    # 3. Group-based Train / Test Splitting by Battery Identifier
    print(f"\n[2/5] Performing leakage-free group split by battery identifier...")
    split_data = create_rul_group_splits(
        validated_df,
        feature_cols=EXPECTED_RUL_OPERATING_FEATURES,
        target_col="rul_target_cycles",
        battery_id_col="battery_id",
        test_size=0.2,
        random_state=random_seed
    )

    X_train_raw = split_data["X_train"]
    X_test_raw = split_data["X_test"]
    y_train = split_data["y_train"]
    y_test = split_data["y_test"]

    print(f"  - Split Method: {split_data['split_type']}")
    print(f"  - Train Battery IDs ({len(split_data['train_groups'])}): {split_data['train_groups']}")
    print(f"  - Test Battery IDs  ({len(split_data['test_groups'])}): {split_data['test_groups']}")
    print(f"  - Train samples: {len(X_train_raw)}, Test samples: {len(X_test_raw)}")

    # 4. Preprocessing Fit Strictly on Training Set
    print(f"\n[3/5] Fitting preprocessing (Imputation & Scaling) strictly on training set...")
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()

    X_train_imp = imputer.fit_transform(X_train_raw)
    X_train_scaled = scaler.fit_transform(X_train_imp)

    X_test_imp = imputer.transform(X_test_raw)
    X_test_scaled = scaler.transform(X_test_imp)

    X_train_df = pd.DataFrame(X_train_scaled, columns=EXPECTED_RUL_OPERATING_FEATURES, index=X_train_raw.index)
    X_test_df = pd.DataFrame(X_test_scaled, columns=EXPECTED_RUL_OPERATING_FEATURES, index=X_test_raw.index)

    # 5. Train Random Forest Regressor
    print(f"\n[4/5] Training Random Forest Regressor...")
    rf_model = RandomForestRegressor(
        n_estimators=100,
        max_depth=6,
        random_state=random_seed,
        n_jobs=-1
    )
    rf_model.fit(X_train_df, y_train)

    # 6. Evaluate on Held-Out Test Data
    print(f"\n[5/5] Evaluating RUL performance on held-out test dataset...")
    rf_preds = rf_model.predict(X_test_df)

    rf_mae = float(mean_absolute_error(y_test, rf_preds))
    rf_rmse = float(np.sqrt(mean_squared_error(y_test, rf_preds)))

    print(f"  --- Random Forest Regressor ---")
    print(f"      MAE:  {rf_mae:.2f} cycles")
    print(f"      RMSE: {rf_rmse:.2f} cycles")
    print(f"      Target RUL Unit: Cycles remaining")

    # 7. Serialize Artifacts
    model_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    rf_model_path = model_dir / "rul_random_forest.joblib"
    rf_meta_path = model_dir / "rul_random_forest_metadata.json"
    eval_json_path = output_dir / "rul_evaluation.json"
    pred_csv_path = output_dir / "rul_predictions.csv"

    pipeline_artifact = {
        "imputer": imputer,
        "scaler": scaler,
        "model": rf_model,
        "feature_names": EXPECTED_RUL_OPERATING_FEATURES,
        "model_type": "Random Forest Regressor",
        "rul_unit": "Cycles remaining",
        "random_seed": random_seed
    }
    joblib.dump(pipeline_artifact, rf_model_path)

    metadata = {
        "model_version": "1.0.0",
        "model_architecture": "Random Forest Regressor",
        "provenance": "Scientific Laboratory Trained",
        "rul_unit": "Cycles remaining",
        "training_date": pd.Timestamp.now().isoformat(),
        "random_seed": random_seed,
        "feature_schema": {
            "feature_names": EXPECTED_RUL_OPERATING_FEATURES,
            "units": {f: RUL_FEATURE_UNITS.get(f, "Unknown") for f in EXPECTED_RUL_OPERATING_FEATURES}
        },
        "training_statistics": {
            "num_train_samples": len(X_train_df),
            "num_test_samples": len(X_test_df),
            "train_battery_ids": split_data["train_groups"],
            "test_battery_ids": split_data["test_groups"],
            "split_type": split_data["split_type"]
        },
        "evaluation_metrics": {
            "random_forest": {
                "mae_cycles": rf_mae,
                "rmse_cycles": rf_rmse,
                "unit": "Cycles remaining"
            }
        }
    }
    with open(rf_meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    evaluation_payload = {
        "evaluation_timestamp": pd.Timestamp.now().isoformat(),
        "model_evaluated": "Random Forest Regressor",
        "metrics": metadata["evaluation_metrics"],
        "data_validation_summary": val_report
    }
    with open(eval_json_path, "w", encoding="utf-8") as f:
        json.dump(evaluation_payload, f, indent=2)

    test_battery_ids = validated_df.loc[X_test_raw.index, "battery_id"].values
    current_cycles = validated_df.loc[X_test_raw.index, "cycle_index"].values
    actual_rul = y_test.values
    pred_rul = rf_preds

    pred_df = pd.DataFrame({
        "battery_id": test_battery_ids,
        "current_cycle": current_cycles,
        "actual_rul": np.round(actual_rul, 1),
        "predicted_rul": np.round(pred_rul, 1),
        "absolute_error": np.round(np.abs(actual_rul - pred_rul), 1)
    })
    pred_df.to_csv(pred_csv_path, index=False)

    def safe_rel(p: Path) -> str:
        try:
            return str(p.relative_to(ROOT))
        except ValueError:
            return str(p)

    print(f"\n[ARTIFACTS SAVED]")
    print(f"  - Model:       {safe_rel(rf_model_path)}")
    print(f"  - Metadata:    {safe_rel(rf_meta_path)}")
    print(f"  - Evaluation:  {safe_rel(eval_json_path)}")
    print(f"  - Predictions: {safe_rel(pred_csv_path)}")

    return {
        "status": "SUCCESS",
        "metadata": metadata,
        "evaluation": evaluation_payload
    }


if __name__ == "__main__":
    train_rul_pipeline()
