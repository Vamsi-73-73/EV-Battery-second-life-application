"""
Scientifically Valid SOH Model Training Pipeline using XGBoost Regressor.

Reads real battery aging data from data/training/soh_training.csv, validates schema,
calculates SOH labels, performs group-based train/test splitting, fits preprocessing strictly
on training data, trains XGBoost & Linear Regression baseline, evaluates metrics on held-out test set,
and serializes artifacts.
"""

from pathlib import Path
import sys
import json
from typing import Optional, Dict, Any, List, Tuple
import numpy as np
import pandas as pd
import joblib
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import xgboost as xgb

# Add project root to sys.path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from src.ml.data_validation import (
    validate_soh_dataset,
    create_group_splits,
    generate_dataset_schema_and_readme,
    EXPECTED_OPERATING_FEATURES,
    FEATURE_UNITS,
    DataValidationError
)


def train_soh_pipeline(
    data_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
    model_dir: Optional[Path] = None,
    random_seed: int = 42
) -> Dict[str, Any]:
    """
    Executes the SOH model training pipeline.

    Args:
        data_path: Path to input training CSV (default: data/training/soh_training.csv).
        output_dir: Path to directory for prediction/evaluation outputs (default: output/ml_predictions).
        model_dir: Path to directory for model artifacts (default: models).
        random_seed: Reproducible random seed.

    Returns:
        Dictionary summary of training results and evaluation metrics.
    """
    if data_path is None:
        data_path = ROOT / "data" / "training" / "soh_training.csv"
    if output_dir is None:
        output_dir = ROOT / "output" / "ml_predictions"
    if model_dir is None:
        model_dir = ROOT / "models"

    training_dir = data_path.parent

    print("=" * 75)
    print("  RE-TWIN: Scientifically Valid XGBoost SOH Model Training Pipeline")
    print("=" * 75)

    # 1. Check if required dataset exists
    if not data_path.exists():
        print(f"\n[STATUS] Training dataset missing at expected location: {data_path.relative_to(ROOT) if data_path.is_relative_to(ROOT) else data_path}")
        schema_file, readme_file = generate_dataset_schema_and_readme(training_dir)
        print(f"[ACTION] Generated dataset schema and README:")
        print(f"  - Schema: {schema_file.relative_to(ROOT) if schema_file.is_relative_to(ROOT) else schema_file}")
        print(f"  - README: {readme_file.relative_to(ROOT) if readme_file.is_relative_to(ROOT) else readme_file}")
        print("\n[EXPLANATION OF MISSING DATA]")
        print("  - Real laboratory battery cycler test data (e.g. NASA, CALCE, Oxford, or OEM cyclers) is required.")
        print("  - The dataset must contain measured discharge capacity and rated capacity across cycling tests.")
        print("  - Synthetic demonstration formulas (SOH_reference_demo) are FORBIDDEN for scientific model training.")
        print("  - Please populate data/training/soh_training.csv according to data/training/README.md to proceed with training.")
        print("=" * 75)
        return {
            "status": "MISSING_DATASET",
            "message": f"Training dataset missing at {data_path}. Schema and README generated.",
            "data_path": str(data_path),
            "readme_path": str(readme_file),
            "schema_path": str(schema_file)
        }

    # 2. Load and Validate Dataset
    print(f"\n[1/5] Loading and validating dataset from: {data_path.name}")
    raw_df = pd.read_csv(data_path)
    validated_df, val_report = validate_soh_dataset(raw_df, operating_features=EXPECTED_OPERATING_FEATURES)
    print(f"  - Input rows: {val_report['total_input_rows']}, Validated rows: {val_report['validated_output_rows']}")
    print(f"  - Unique Battery IDs: {val_report['battery_ids_found']}")

    if val_report["warnings"]:
        for w in val_report["warnings"]:
            print(f"  - Warning: {w}")

    # 3. Group-based Train / Test Splitting
    print(f"\n[2/5] Performing leakage-free group split by battery identifier...")
    split_data = create_group_splits(
        validated_df,
        feature_cols=EXPECTED_OPERATING_FEATURES,
        target_col="soh_target_ratio",
        battery_id_col="battery_id",
        test_size=0.2,
        random_state=random_seed
    )

    X_train_raw = split_data["X_train"]
    X_test_raw = split_data["X_test"]
    y_train = split_data["y_train"]
    y_test = split_data["y_test"]

    print(f"  - Split Method: {split_data['split_type']}")
    print(f"  - Train Battery IDs ({len(split_data['train_groups'])}): {split_data['train_groups']}")
    print(f"  - Test Battery IDs  ({len(split_data['test_groups'])}): {split_data['test_groups']}")
    print(f"  - Train samples: {len(X_train_raw)}, Test samples: {len(X_test_raw)}")

    # 4. Preprocessing Fit Strictly on Training Data
    print(f"\n[3/5] Fitting preprocessing (Imputation & Scaling) strictly on training set...")
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()

    X_train_imp = imputer.fit_transform(X_train_raw)
    X_train_scaled = scaler.fit_transform(X_train_imp)

    X_test_imp = imputer.transform(X_test_raw)
    X_test_scaled = scaler.transform(X_test_imp)

    # Convert back to DataFrame to preserve feature column names for XGBoost
    X_train_df = pd.DataFrame(X_train_scaled, columns=EXPECTED_OPERATING_FEATURES, index=X_train_raw.index)
    X_test_df = pd.DataFrame(X_test_scaled, columns=EXPECTED_OPERATING_FEATURES, index=X_test_raw.index)

    # 5. Train Models (XGBoost & Linear Regression Baseline)
    print(f"\n[4/5] Training XGBoost Regressor and Linear Regression baseline...")
    xgb_model = xgb.XGBRegressor(
        n_estimators=150,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=random_seed,
        n_jobs=-1
    )
    xgb_model.fit(X_train_df, y_train)

    lr_model = LinearRegression()
    lr_model.fit(X_train_df, y_train)

    # 6. Evaluation on Held-Out Test Data
    print(f"\n[5/5] Evaluating performance on held-out test dataset...")
    xgb_preds = xgb_model.predict(X_test_df)
    lr_preds = lr_model.predict(X_test_df)

    # Metric calculations
    xgb_mae = float(mean_absolute_error(y_test, xgb_preds))
    xgb_rmse = float(np.sqrt(mean_squared_error(y_test, xgb_preds)))
    xgb_r2 = float(r2_score(y_test, xgb_preds))

    lr_mae = float(mean_absolute_error(y_test, lr_preds))
    lr_rmse = float(np.sqrt(mean_squared_error(y_test, lr_preds)))
    lr_r2 = float(r2_score(y_test, lr_preds))

    print(f"  --- XGBoost Regressor ---")
    print(f"      MAE:  {xgb_mae:.6f} ({xgb_mae*100:.3f}% SOH)")
    print(f"      RMSE: {xgb_rmse:.6f} ({xgb_rmse*100:.3f}% SOH)")
    print(f"      R2:   {xgb_r2:.6f}")

    print(f"  --- Linear Regression Baseline ---")
    print(f"      MAE:  {lr_mae:.6f} ({lr_mae*100:.3f}% SOH)")
    print(f"      RMSE: {lr_rmse:.6f} ({lr_rmse*100:.3f}% SOH)")
    print(f"      R2:   {lr_r2:.6f}")

    # Empirical comparison
    xgb_is_better = (xgb_rmse < lr_rmse) and (xgb_r2 > lr_r2)
    comparison_statement = (
        "XGBoost Regressor achieved superior performance over Linear Regression baseline on held-out test data."
        if xgb_is_better else
        "Linear Regression baseline performed comparably or better than XGBoost Regressor on the test set."
    )
    print(f"\n[CONCLUSION] {comparison_statement}")

    # 7. Serialize Artifacts
    model_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    xgb_model_path = model_dir / "soh_xgboost.joblib"
    xgb_meta_path = model_dir / "soh_xgboost_metadata.json"
    eval_json_path = output_dir / "soh_evaluation.json"
    pred_csv_path = output_dir / "soh_predictions.csv"

    # Save fitted Pipeline container (imputer + scaler + xgb_model)
    pipeline_artifact = {
        "imputer": imputer,
        "scaler": scaler,
        "model": xgb_model,
        "feature_names": EXPECTED_OPERATING_FEATURES,
        "model_type": "XGBoost Regressor",
        "random_seed": random_seed
    }
    joblib.dump(pipeline_artifact, xgb_model_path)

    # Save Metadata JSON
    metadata = {
        "model_version": "1.0.0",
        "model_architecture": "XGBoost Regressor",
        "provenance": "Scientific Laboratory Trained",
        "training_date": pd.Timestamp.now().isoformat(),
        "random_seed": random_seed,
        "feature_schema": {
            "feature_names": EXPECTED_OPERATING_FEATURES,
            "units": {f: FEATURE_UNITS.get(f, "Unknown") for f in EXPECTED_OPERATING_FEATURES}
        },
        "training_statistics": {
            "num_train_samples": len(X_train_df),
            "num_test_samples": len(X_test_df),
            "train_battery_ids": split_data["train_groups"],
            "test_battery_ids": split_data["test_groups"],
            "split_type": split_data["split_type"]
        },
        "evaluation_metrics": {
            "xgboost": {
                "mae": xgb_mae,
                "rmse": xgb_rmse,
                "r2": xgb_r2
            },
            "linear_regression_baseline": {
                "mae": lr_mae,
                "rmse": lr_rmse,
                "r2": lr_r2
            },
            "xgb_outperforms_baseline": xgb_is_better,
            "conclusion": comparison_statement
        }
    }
    with open(xgb_meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    # Save Evaluation JSON
    evaluation_payload = {
        "evaluation_timestamp": pd.Timestamp.now().isoformat(),
        "models_evaluated": ["XGBoost Regressor", "Linear Regression Baseline"],
        "metrics": metadata["evaluation_metrics"],
        "data_validation_summary": val_report
    }
    with open(eval_json_path, "w", encoding="utf-8") as f:
        json.dump(evaluation_payload, f, indent=2)

    # Save Test Predictions CSV
    test_battery_ids = validated_df.loc[X_test_raw.index, "battery_id"].values
    actual_soh = y_test.values
    pred_soh = xgb_preds

    pred_df = pd.DataFrame({
        "battery_id": test_battery_ids,
        "actual_soh": np.round(actual_soh, 4),
        "predicted_soh": np.round(pred_soh, 4),
        "absolute_error": np.round(np.abs(actual_soh - pred_soh), 4)
    })
    pred_df.to_csv(pred_csv_path, index=False)

    def safe_rel(p: Path) -> str:
        try:
            return str(p.relative_to(ROOT))
        except ValueError:
            return str(p)

    print(f"\n[ARTIFACTS SAVED]")
    print(f"  - Model:       {safe_rel(xgb_model_path)}")
    print(f"  - Metadata:    {safe_rel(xgb_meta_path)}")
    print(f"  - Evaluation:  {safe_rel(eval_json_path)}")
    print(f"  - Predictions: {safe_rel(pred_csv_path)}")

    return {
        "status": "SUCCESS",
        "metadata": metadata,
        "evaluation": evaluation_payload
    }


if __name__ == "__main__":
    train_soh_pipeline()
