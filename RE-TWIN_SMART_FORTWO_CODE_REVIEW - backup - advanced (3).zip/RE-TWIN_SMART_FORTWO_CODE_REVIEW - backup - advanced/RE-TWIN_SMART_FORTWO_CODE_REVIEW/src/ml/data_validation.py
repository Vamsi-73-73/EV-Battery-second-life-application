"""
Data Validation & Preparation Pipeline for Battery State-of-Health (SOH) Training.

Implements rigorous data validation, scientific SOH label calculation,
data leakage checks, and group-based splitting by battery identifier.
"""

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

# Standard feature schema for SOH prediction
EXPECTED_OPERATING_FEATURES = [
    "SOC",
    "TempMean",
    "CellVoltageImbalance",
    "PackVoltage",
    "PackCurrent",
    "PackPower_W",
    "Throughput_Ah"
]

FEATURE_UNITS = {
    "SOC": "% (0.0 to 100.0)",
    "TempMean": "°C (-40.0 to 100.0)",
    "CellVoltageImbalance": "V (0.0 to 1.0)",
    "PackVoltage": "V (0.0 to 1000.0)",
    "PackCurrent": "A (-500.0 to 500.0)",
    "PackPower_W": "W",
    "Throughput_Ah": "Ah (>= 0.0)",
    "measured_capacity_ah": "Ah (>= 0.0)",
    "rated_capacity_ah": "Ah (> 0.0)",
    "battery_id": "String / Categorical Identifier",
    "cycle_index": "Integer (>= 0)"
}


class DataValidationError(Exception):
    """Raised when data validation fails critical checks."""
    pass


def calculate_soh(
    df: pd.DataFrame,
    measured_col: str = "measured_capacity_ah",
    rated_col: str = "rated_capacity_ah",
    soh_col: str = "soh_pct"
) -> Tuple[pd.Series, pd.Series]:
    """
    Calculates SOH percentage and SOH decimal ratio from measured and rated capacity:
    SOH (%) = Measured Capacity / Rated Capacity * 100

    If verified SOH labels exist in df, validates them against calculated SOH.

    Returns:
        soh_pct: pd.Series (0.0 to 100.0 %)
        soh_ratio: pd.Series (0.0 to 1.0 ratio)
    """
    if measured_col in df.columns and rated_col in df.columns:
        invalid_rated = (df[rated_col] <= 0) | df[rated_col].isna()
        if invalid_rated.any():
            raise DataValidationError(f"Found {invalid_rated.sum()} rows with invalid or zero rated capacity.")

        invalid_measured = (df[measured_col] < 0) | df[measured_col].isna()
        if invalid_measured.any():
            raise DataValidationError(f"Found {invalid_measured.sum()} rows with negative or missing measured capacity.")

        calc_pct = (df[measured_col] / df[rated_col]) * 100.0
        calc_ratio = df[measured_col] / df[rated_col]

        # Check existing SOH labels if present
        if soh_col in df.columns:
            soh_existing = df[soh_col].astype(float)
            # Check if existing SOH is in ratio (0..1) or percentage (0..100)
            if soh_existing.max() <= 1.0:
                soh_existing_pct = soh_existing * 100.0
            else:
                soh_existing_pct = soh_existing

            diff = (soh_existing_pct - calc_pct).abs()
            discrepancies = (diff > 2.0).sum()
            if discrepancies > 0:
                print(f"[WARNING] {discrepancies} rows have existing SOH labels differing from Measured/Rated Capacity calculation by >2.0%. Using calculated SOH.")
        
        return calc_pct.round(4), calc_ratio.round(6)

    elif soh_col in df.columns or "soh" in df.columns:
        target_col = soh_col if soh_col in df.columns else "soh"
        raw_val = df[target_col].astype(float)
        if raw_val.max() <= 1.0:
            return (raw_val * 100.0).round(4), raw_val.round(6)
        else:
            return raw_val.round(4), (raw_val / 100.0).round(6)
    else:
        raise DataValidationError(
            f"Dataset must contain either ('{measured_col}', '{rated_col}') or '{soh_col}'/'soh' column."
        )


def validate_soh_dataset(
    df: pd.DataFrame,
    operating_features: Optional[List[str]] = None,
    battery_id_col: str = "battery_id"
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Validates column names, units, missing values, range bounds, duplicate records,
    and data leakage in the training dataset.

    Returns:
        validated_df: Clean DataFrame with calculated 'soh_target_pct' and 'soh_target_ratio'.
        report: Dictionary summary of validation findings.
    """
    if operating_features is None:
        operating_features = EXPECTED_OPERATING_FEATURES

    report: Dict[str, Any] = {
        "total_input_rows": len(df),
        "total_input_cols": len(df.columns),
        "missing_features": [],
        "duplicate_rows_removed": 0,
        "invalid_range_rows_removed": 0,
        "battery_ids_found": [],
        "warnings": [],
        "validation_passed": True
    }

    df_clean = df.copy()

    # 1. Validate Battery Identifier
    if battery_id_col not in df_clean.columns:
        # Check alternative battery ID columns
        alts = [c for c in ["pack_id", "cell_id", "battery", "id"] if c in df_clean.columns]
        if alts:
            df_clean = df_clean.rename(columns={alts[0]: battery_id_col})
            report["warnings"].append(f"Renamed column '{alts[0]}' to '{battery_id_col}'")
        else:
            raise DataValidationError(f"Missing required battery identifier column '{battery_id_col}'.")

    report["battery_ids_found"] = df_clean[battery_id_col].astype(str).unique().tolist()

    # 2. Validate Operating Features
    missing_feats = [f for f in operating_features if f not in df_clean.columns]
    if missing_feats:
        report["missing_features"] = missing_feats
        raise DataValidationError(f"Dataset is missing required operating features: {missing_feats}")

    # 3. Calculate and Validate SOH Target
    soh_pct, soh_ratio = calculate_soh(df_clean)
    df_clean["soh_target_pct"] = soh_pct
    df_clean["soh_target_ratio"] = soh_ratio

    # 4. Check Duplicate Records
    subset_cols = [battery_id_col] + operating_features
    if "cycle_index" in df_clean.columns:
        subset_cols.append("cycle_index")
    elif "timestamp" in df_clean.columns:
        subset_cols.append("timestamp")

    dups = df_clean.duplicated(subset=subset_cols, keep="first")
    n_dups = int(dups.sum())
    if n_dups > 0:
        report["duplicate_rows_removed"] = n_dups
        report["warnings"].append(f"Removed {n_dups} duplicate records.")
        df_clean = df_clean[~dups].reset_index(drop=True)

    # 5. Check Feature Range Bounds
    range_checks = {
        "SOC": (0.0, 100.0),
        "TempMean": (-40.0, 100.0),
        "CellVoltageImbalance": (0.0, 1.0),
        "PackVoltage": (0.0, 1000.0),
        "PackCurrent": (-500.0, 500.0),
        "Throughput_Ah": (0.0, 1e6),
        "soh_target_pct": (10.0, 105.0)  # SOH should be physically realistic
    }

    initial_len = len(df_clean)
    valid_mask = pd.Series([True] * len(df_clean), index=df_clean.index)

    for col, (min_val, max_val) in range_checks.items():
        if col in df_clean.columns:
            out_of_bounds = (df_clean[col] < min_val) | (df_clean[col] > max_val) | df_clean[col].isna()
            if out_of_bounds.any():
                n_bad = int(out_of_bounds.sum())
                report["warnings"].append(f"Column '{col}' had {n_bad} out-of-bounds or NaN values [{min_val}, {max_val}].")
                valid_mask = valid_mask & (~out_of_bounds)

    df_clean = df_clean[valid_mask].reset_index(drop=True)
    report["invalid_range_rows_removed"] = initial_len - len(df_clean)
    report["validated_output_rows"] = len(df_clean)

    if len(df_clean) == 0:
        raise DataValidationError("No valid rows remaining after data validation checks.")

    # 6. Check Data Leakage
    # Ensure target column or capacity variables are not in feature set
    leakage_cols = ["soh", "soh_pct", "soh_target_pct", "soh_target_ratio", "measured_capacity_ah", "rated_capacity_ah"]
    for f in operating_features:
        if f.lower() in [l.lower() for l in leakage_cols]:
            raise DataValidationError(f"Data leakage detected! Feature '{f}' is directly derived from the target variable.")

    return df_clean, report


def create_group_splits(
    df: pd.DataFrame,
    feature_cols: List[str],
    target_col: str = "soh_target_ratio",
    battery_id_col: str = "battery_id",
    test_size: float = 0.2,
    random_state: int = 42
) -> Dict[str, Any]:
    """
    Creates group-based train/test splits by battery identifier to strictly prevent data leakage.
    If only one battery ID exists, falls back to time-series / row split with warning.
    """
    groups = df[battery_id_col].astype(str)
    unique_groups = groups.unique()

    X = df[feature_cols].copy()
    y = df[target_col].copy()

    if len(unique_groups) > 1:
        gss = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=random_state)
        train_idx, test_idx = next(gss.split(X, y, groups=groups))

        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
        train_groups = groups.iloc[train_idx].unique().tolist()
        test_groups = groups.iloc[test_idx].unique().tolist()
        split_type = "GroupShuffleSplit"
    else:
        # Single battery ID fallback split (e.g. first 80% train, last 20% test to prevent time leakage)
        split_point = int(len(df) * (1 - test_size))
        X_train, X_test = X.iloc[:split_point], X.iloc[split_point:]
        y_train, y_test = y.iloc[:split_point], y.iloc[split_point:]
        train_groups = unique_groups.tolist()
        test_groups = unique_groups.tolist()
        split_type = "SequentialTimeSplit (Single Battery ID)"

    # Verify zero group leakage for GroupShuffleSplit
    if split_type == "GroupShuffleSplit":
        overlap = set(train_groups).intersection(set(test_groups))
        if overlap:
            raise DataValidationError(f"Data leakage detected! Battery IDs overlap between train and test: {overlap}")

    return {
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "train_groups": train_groups,
        "test_groups": test_groups,
        "split_type": split_type
    }


def generate_dataset_schema_and_readme(output_dir: Path) -> Tuple[Path, Path]:
    """
    Generates data/training/README.md and data/training/schema.json detailing
    the required battery SOH training dataset specification.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    readme_path = output_dir / "README.md"
    schema_path = output_dir / "schema.json"

    schema_data = {
        "dataset_name": "RE-TWIN Battery SOH Training Dataset",
        "expected_filename": "soh_training.csv",
        "target_variable": "measured_capacity_ah / rated_capacity_ah * 100 (SOH %)",
        "required_columns": {
            "battery_id": "Unique string identifier for battery pack/cell (e.g., 'BAT_PACK_01')",
            "measured_capacity_ah": "Measured discharge capacity in Ampere-hours (Ah) from laboratory cycler test",
            "rated_capacity_ah": "Nominal rated battery capacity in Ampere-hours (Ah) when new",
            "SOC": "State of Charge percentage (0.0 to 100.0 %)",
            "TempMean": "Mean battery operating temperature in degrees Celsius (°C)",
            "CellVoltageImbalance": "Maximum cell-to-cell voltage imbalance in Volts (V)",
            "PackVoltage": "Total pack terminal voltage in Volts (V)",
            "PackCurrent": "Pack current in Amperes (A), positive for discharge, negative for charge",
            "PackPower_W": "Pack power in Watts (W)",
            "Throughput_Ah": "Cumulative charge throughput in Ampere-hours (Ah)"
        },
        "optional_columns": {
            "cycle_index": "Integer degradation cycle count (0, 1, 2, ...)",
            "timestamp": "ISO-8601 string or Unix timestamp in seconds"
        },
        "data_validation_rules": [
            "battery_id must be present for group-based train/val/test splitting.",
            "measured_capacity_ah must be >= 0.0 and <= 1.25 * rated_capacity_ah.",
            "rated_capacity_ah must be > 0.0.",
            "No synthetic SOH targets or synthetic demonstration labels are permitted.",
            "Operating features must be measured/recorded from real battery cycler tests or CAN telemetry."
        ]
    }

    with open(schema_path, "w", encoding="utf-8") as f:
        json.dump(schema_data, f, indent=2)

    readme_content = """# RE-TWIN SOH Training Dataset Specification

## Location
Expected training dataset file: `data/training/soh_training.csv`

## Overview
This directory is designated for laboratory battery cycler training data used to train scientifically valid State of Health (SOH) machine learning models (e.g., XGBoost Regressor).

## Dataset Schema Requirements

| Column Name | Type | Unit / Format | Required | Description |
|---|---|---|---|---|
| `battery_id` | String | e.g. `"BAT_PACK_01"` | Yes | Battery cell/pack group identifier for leakage-free splitting |
| `measured_capacity_ah` | Float | Ah | Yes | Actual measured discharge capacity at reference temperature |
| `rated_capacity_ah` | Float | Ah | Yes | Nominal fresh cell capacity |
| `SOC` | Float | % (0.0 - 100.0) | Yes | State of Charge |
| `TempMean` | Float | °C | Yes | Average battery module temperature |
| `CellVoltageImbalance` | Float | V | Yes | Maximum voltage spread across series cells |
| `PackVoltage` | Float | V | Yes | Total pack voltage |
| `PackCurrent` | Float | A | Yes | Pack current |
| `PackPower_W` | Float | W | Yes | Electrical power |
| `Throughput_Ah` | Float | Ah | Yes | Cumulative charge throughput |
| `cycle_index` | Integer | Count | Optional | Degradation cycle index |

## SOH Formula
State of Health is calculated as:
$$\\text{SOH (\\%)} = \\frac{\\text{Measured Capacity (Ah)}}{\\text{Rated Capacity (Ah)}} \\times 100$$

## Missing Dataset Status Notice
If `data/training/soh_training.csv` is missing, the training pipeline (`src/ml/train_soh.py`) will notify the user and generate this schema specification.
**Synthetic SOH labels and physics-inspired demonstration formulas (`SOH_reference_demo`) must NEVER be used to train production models.** Real laboratory cycler data (e.g. NASA, CALCE, Oxford, or OEM cycler tests) must be placed in `data/training/soh_training.csv`.
"""

    with open(readme_path, "w", encoding="utf-8") as f:
        f.write(readme_content)

    return schema_path, readme_path
