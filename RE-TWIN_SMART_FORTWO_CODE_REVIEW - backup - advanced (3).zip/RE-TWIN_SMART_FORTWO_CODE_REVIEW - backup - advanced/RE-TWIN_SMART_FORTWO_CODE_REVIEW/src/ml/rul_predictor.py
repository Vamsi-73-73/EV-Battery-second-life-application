"""
Reusable Prediction Interface for Battery Remaining Useful Life (RUL) Estimation using Random Forest Regressor.

Validates input features, loads fitted Random Forest pipeline artifact, reports model versioning,
provenance, and unit ("Cycles remaining"), and clearly labels outputs as model estimates.
"""

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Union
import json
import numpy as np
import pandas as pd
import joblib

RUL_FEATURES = [
    "SOC",
    "TempMean",
    "CellVoltageImbalance",
    "PackVoltage",
    "PackCurrent",
    "PackPower_W",
    "Throughput_Ah",
    "cycle_index"
]


class RULPredictor:
    def __init__(self, model_path: Optional[Union[str, Path]] = None, strict_validation: bool = False):
        self.model: Any = None
        self.imputer: Any = None
        self.scaler: Any = None
        self.feature_names: List[str] = RUL_FEATURES.copy()
        self.model_type: str = "Random Forest Regressor"
        self.rul_unit: str = "Cycles remaining"
        self.provenance: str = "Scientific Laboratory Trained"
        self.model_version: str = "1.0.0"
        self.strict_validation: bool = strict_validation
        self.model_path: Optional[Path] = Path(model_path) if model_path else None

        if self.model_path and self.model_path.exists():
            self.load(self.model_path)

    def load(self, path: Path):
        """
        Loads serialized Random Forest RUL pipeline artifact container.
        """
        self.model_path = Path(path)
        artifact = joblib.load(self.model_path)

        if isinstance(artifact, dict) and "model" in artifact:
            self.model = artifact["model"]
            self.imputer = artifact.get("imputer")
            self.scaler = artifact.get("scaler")
            self.feature_names = artifact.get("feature_names", RUL_FEATURES)
            self.model_type = artifact.get("model_type", "Random Forest Regressor")
            self.rul_unit = artifact.get("rul_unit", "Cycles remaining")
            self.provenance = "Scientific Laboratory Trained"

            meta_path = self.model_path.with_name("rul_random_forest_metadata.json")
            if meta_path.exists():
                try:
                    with open(meta_path, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                        self.model_version = meta.get("model_version", "1.0.0")
                        self.provenance = meta.get("provenance", self.provenance)
                except Exception:
                    pass
        else:
            self.model = artifact
            self.imputer = None
            self.scaler = None
            self.model_type = "Random Forest Regressor"

    def validate_input_features(self, snapshot_dict: Dict[str, Any]) -> Tuple[bool, List[str], List[str]]:
        """
        Validates input feature dict against saved RUL feature schema.

        Returns:
            is_valid: bool
            missing_features: List[str]
            incompatible_features: List[str]
        """
        missing = []
        incompatible = []

        for f in self.feature_names:
            val = snapshot_dict.get(f)
            if val is None:
                missing.append(f)
            else:
                try:
                    float_val = float(val)
                    if np.isnan(float_val) or np.isinf(float_val):
                        incompatible.append(f"{f} (NaN/Inf)")
                except (ValueError, TypeError):
                    incompatible.append(f"{f} (non-numeric)")

        is_valid = (len(missing) == 0) and (len(incompatible) == 0)
        return is_valid, missing, incompatible

    def get_model_info(self) -> Dict[str, Any]:
        """Returns RUL model version, architecture, provenance, and applicability notices."""
        return {
            "model_version": self.model_version,
            "model_architecture": self.model_type,
            "provenance": self.provenance,
            "rul_unit": self.rul_unit,
            "estimation_notice": "MODEL ESTIMATE (Machine Learning RUL Prediction)",
            "domain_applicability_notice": (
                "RUL predictions require laboratory cycler validation. "
                "Do not claim a certified RUL estimate for Smart fortwo without established applicability."
            ),
            "feature_schema": self.feature_names,
            "is_loaded": self.model is not None
        }

    def predict_single(self, snapshot_dict: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
        """
        Predicts Remaining Useful Life for a single battery operational snapshot.

        Returns:
            predicted_rul: float (Cycles remaining, clamped >= 0)
            diagnostic_dict: Dict containing unit, model version, and attributions.
        """
        is_valid, missing, incompatible = self.validate_input_features(snapshot_dict)
        if not is_valid and self.strict_validation:
            raise ValueError(
                f"Feature validation failed for RUL predictor! Missing: {missing}, Incompatible: {incompatible}"
            )

        if self.model is None:
            # Safe default fallback if model is not loaded
            return 0.0, {
                "rul_unit": self.rul_unit,
                "model_version": self.model_version,
                "estimation_notice": "UNLOADED_MODEL_DEFAULT"
            }

        row = {f: float(snapshot_dict.get(f, 0.0) or 0.0) for f in self.feature_names}
        X_df = pd.DataFrame([row])

        if self.imputer is not None:
            X_prep = self.imputer.transform(X_df)
        else:
            X_prep = X_df

        if self.scaler is not None:
            X_prep = self.scaler.transform(X_prep)
            X_prep = pd.DataFrame(X_prep, columns=self.feature_names)

        raw_pred = float(self.model.predict(X_prep)[0])
        rul_clamped = float(max(0.0, raw_pred))

        attributions: Dict[str, float] = {}
        if hasattr(self.model, "feature_importances_"):
            for name, imp in zip(self.feature_names, self.model.feature_importances_):
                attributions[name] = round(float(imp), 5)

        diagnostics = {
            "predicted_rul": round(rul_clamped, 1),
            "rul_unit": self.rul_unit,
            "model_version": self.model_version,
            "model_architecture": self.model_type,
            "provenance": self.provenance,
            "estimation_notice": "MODEL ESTIMATE (Machine Learning RUL Prediction)",
            "feature_importances": attributions
        }

        return round(rul_clamped, 1), diagnostics

    def predict_dataframe(self, df: pd.DataFrame) -> pd.Series:
        """
        Runs batch RUL inference across DataFrame.
        """
        if self.model is None:
            return pd.Series([0.0] * len(df))

        X = df.copy()
        for f in self.feature_names:
            if f not in X.columns:
                X[f] = 0.0

        X = X[self.feature_names].replace([np.inf, -np.inf], np.nan)

        if self.imputer is not None:
            X_prep = self.imputer.transform(X)
        else:
            X_prep = X.ffill().bfill().fillna(0)

        if self.scaler is not None:
            X_prep = self.scaler.transform(X_prep)
            X_prep = pd.DataFrame(X_prep, columns=self.feature_names)

        preds = self.model.predict(X_prep)
        return pd.Series(np.clip(preds, 0.0, None)).round(1)
