"""
Data Preparation & Validation Pipeline for Remaining Useful Life (RUL) Training.

Implements EOL threshold validation, RUL target calculation (EOL cycle - Current cycle),
data leakage prevention, and group-based splitting by battery identifier.
"""

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

EXPECTED_RUL_OPERATING_FEATURES = [
    "SOC",
    "TempMean",
    "CellVoltageImbalance",
    "PackVoltage",
    "PackCurrent",
    "PackPower_W",
    "Throughput_Ah",
    "cycle_index"
]

RUL_FEATURE_UNITS = {
    "SOC": "% (0.0 to 100.0)",
    "TempMean": "°C (-40.0 to 100.0)",
    "CellVoltageImbalance": "V (0.0 to 1.0)",
    "PackVoltage": "V (0.0 to 1000.0)",
    "PackCurrent": "A (-500.0 to 500.0)",
    "PackPower_W": "W",
    "Throughput_Ah": "Ah (>= 0.0)",
    "cycle_index": "Integer cycle count (>= 0)",
    "battery_id": "String / Categorical Identifier",
    "measured_capacity_ah": "Ah (>= 0.0)",
    "rated_capacity_ah": "Ah (> 0.0)",
    "eol_cycle": "Integer End-of-Life cycle index",
    "rul_target_cycles": "Cycles remaining (>= 0)"
}


class RULDataValidationError(Exception):
    """Raised when RUL data validation fails critical scientific checks."""
    pass


def calculate_rul_target(
    df: pd.DataFrame,
    battery_id_col: str = "battery_id",
    cycle_col: str = "cycle_index",
    measured_col: str = "measured_capacity_ah",
    rated_col: str = "rated_capacity_ah",
    eol_col: str = "eol_cycle",
    eol_threshold_pct: float = 80.0
) -> pd.Series:
    """
    Calculates RUL target in cycles:
    RUL = EOL cycle - Current cycle

    If eol_cycle column exists in df, uses documented eol_cycle per row.
    Otherwise, determines EOL cycle per battery group as the cycle index
    where capacity retention drops below eol_threshold_pct (default: 80.0%).

    Returns:
        rul_series: pd.Series of integer cycles remaining (>= 0).
    """
    df_copy = df.copy()

    if cycle_col not in df_copy.columns:
        raise RULDataValidationError(f"Required cycle column '{cycle_col}' is missing.")

    # 1. If explicit eol_col is present in dataframe
    if eol_col in df_copy.columns:
        invalid_eol = df_copy[eol_col] < df_copy[cycle_col]
        if invalid_eol.any():
            n_bad = int(invalid_eol.sum())
            raise RULDataValidationError(f"Found {n_bad} rows where eol_cycle < current cycle_index.")
        rul = (df_copy[eol_col] - df_copy[cycle_col]).astype(int)
        return rul

    # 2. Derive EOL cycle per battery_id using capacity retention threshold
    if measured_col not in df_copy.columns or rated_col not in df_copy.columns:
        raise RULDataValidationError(
            f"Dataset must contain either '{eol_col}' or both ('{measured_col}', '{rated_col}') to calculate RUL."
        )

    df_copy["retention_pct"] = (df_copy[measured_col] / df_copy[rated_col]) * 100.0

    eol_map = {}
    grouped = df_copy.groupby(battery_id_col)

    for b_id, group in grouped:
        # Sort by cycle
        group_sorted = group.sort_values(cycle_col)
        eol_rows = group_sorted[group_sorted["retention_pct"] <= eol_threshold_pct]
        if not eol_rows.empty:
            eol_cycle_val = int(eol_rows.iloc[0][cycle_col])
            eol_map[b_id] = eol_cycle_val
        else:
            # Battery never reached EOL in dataset
            max_cycle = int(group_sorted[cycle_col].max())
            print(f"[WARNING] Battery ID '{b_id}' never reached EOL threshold ({eol_threshold_pct}%). Using max cycle {max_cycle} as boundary.")
            eol_map[b_id] = max_cycle

    calculated_eol = df_copy[battery_id_col].map(eol_map)
    invalid_rows = df_copy[cycle_col] > calculated_eol
    
    # Filter or clamp post-EOL cycles
    rul = (calculated_eol - df_copy[cycle_col]).clip(lower=0).astype(int)
    return rul


def validate_rul_dataset(
    df: pd.DataFrame,
    operating_features: Optional[List[str]] = None,
    battery_id_col: str = "battery_id",
    cycle_col: str = "cycle_index",
    eol_threshold_pct: float = 80.0
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Validates RUL training dataset column names, units, missing values,
    range bounds, duplicates, and data leakage.

    Returns:
        validated_df: Clean DataFrame with 'rul_target_cycles' column.
        report: Dictionary summary of validation findings.
    """
    if operating_features is None:
        operating_features = EXPECTED_RUL_OPERATING_FEATURES

    report: Dict[str, Any] = {
        "total_input_rows": len(df),
        "total_input_cols": len(df.columns),
        "missing_features": [],
        "duplicate_rows_removed": 0,
        "invalid_range_rows_removed": 0,
        "battery_ids_found": [],
        "warnings": [],
        "rul_unit": "Cycles remaining",
        "eol_threshold_pct": eol_threshold_pct,
        "validation_passed": True
    }

    df_clean = df.copy()

    # 1. Validate Battery Identifier
    if battery_id_col not in df_clean.columns:
        alts = [c for c in ["pack_id", "cell_id", "battery", "id"] if c in df_clean.columns]
        if alts:
            df_clean = df_clean.rename(columns={alts[0]: battery_id_col})
            report["warnings"].append(f"Renamed '{alts[0]}' to '{battery_id_col}'")
        else:
            raise RULDataValidationError(f"Missing required battery identifier '{battery_id_col}'.")

    report["battery_ids_found"] = df_clean[battery_id_col].astype(str).unique().tolist()

    # 2. Validate Cycle Index Column
    if cycle_col not in df_clean.columns:
        alts = [c for c in ["cycle", "cycle_number", "cycles"] if c in df_clean.columns]
        if alts:
            df_clean = df_clean.rename(columns={alts[0]: cycle_col})
            report["warnings"].append(f"Renamed '{alts[0]}' to '{cycle_col}'")
        else:
            raise RULDataValidationError(f"Missing required cycle index column '{cycle_col}'.")

    # 3. Validate Operating Features
    missing_feats = [f for f in operating_features if f not in df_clean.columns]
    if missing_feats:
        report["missing_features"] = missing_feats
        raise RULDataValidationError(f"Dataset is missing required RUL operating features: {missing_feats}")

    # 4. Calculate RUL Target
    rul_target = calculate_rul_target(
        df_clean,
        battery_id_col=battery_id_col,
        cycle_col=cycle_col,
        eol_threshold_pct=eol_threshold_pct
    )
    df_clean["rul_target_cycles"] = rul_target

    # 5. Check Duplicate Records
    subset_cols = [battery_id_col, cycle_col]
    dups = df_clean.duplicated(subset=subset_cols, keep="first")
    n_dups = int(dups.sum())
    if n_dups > 0:
        report["duplicate_rows_removed"] = n_dups
        report["warnings"].append(f"Removed {n_dups} duplicate cycle records.")
        df_clean = df_clean[~dups].reset_index(drop=True)

    # 6. Check Feature Range Bounds
    range_checks = {
        cycle_col: (0, 100000),
        "SOC": (0.0, 100.0),
        "TempMean": (-40.0, 100.0),
        "CellVoltageImbalance": (0.0, 1.0),
        "PackVoltage": (0.0, 1000.0),
        "PackCurrent": (-500.0, 500.0),
        "Throughput_Ah": (0.0, 1e7),
        "rul_target_cycles": (0, 100000)
    }

    initial_len = len(df_clean)
    valid_mask = pd.Series([True] * len(df_clean), index=df_clean.index)

    for col, (min_val, max_val) in range_checks.items():
        if col in df_clean.columns:
            out_of_bounds = (df_clean[col] < min_val) | (df_clean[col] > max_val) | df_clean[col].isna()
            if out_of_bounds.any():
                n_bad = int(out_of_bounds.sum())
                report["warnings"].append(f"Column '{col}' had {n_bad} invalid or NaN values.")
                valid_mask = valid_mask & (~out_of_bounds)

    df_clean = df_clean[valid_mask].reset_index(drop=True)
    report["invalid_range_rows_removed"] = initial_len - len(df_clean)
    report["validated_output_rows"] = len(df_clean)

    if len(df_clean) == 0:
        raise RULDataValidationError("No valid rows remaining after RUL data validation checks.")

    # 7. Check Data Leakage
    leakage_cols = ["eol_cycle", "rul", "rul_target_cycles", "measured_capacity_ah", "rated_capacity_ah"]
    for f in operating_features:
        if f.lower() in [l.lower() for l in leakage_cols if l != "cycle_index"]:
            raise RULDataValidationError(f"Data leakage detected! Feature '{f}' is directly derived from RUL target or future measurements.")

    return df_clean, report


def create_rul_group_splits(
    df: pd.DataFrame,
    feature_cols: List[str],
    target_col: str = "rul_target_cycles",
    battery_id_col: str = "battery_id",
    test_size: float = 0.2,
    random_state: int = 42
) -> Dict[str, Any]:
    """
    Creates group-based train/test splits by battery identifier to strictly prevent RUL data leakage across batteries.
    """
    groups = df[battery_id_col].astype(str)
    unique_groups = groups.unique()

    X = df[feature_cols].copy()
    y = df[target_col].copy()

    if len(unique_groups) > 1:
        gss = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=random_state)
        train_idx, test_idx = next(gss.split(X, y, groups=groups))

        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
        train_groups = groups.iloc[train_idx].unique().tolist()
        test_groups = groups.iloc[test_idx].unique().tolist()
        split_type = "GroupShuffleSplit"
    else:
        split_point = int(len(df) * (1 - test_size))
        X_train, X_test = X.iloc[:split_point], X.iloc[split_point:]
        y_train, y_test = y.iloc[:split_point], y.iloc[split_point:]
        train_groups = unique_groups.tolist()
        test_groups = unique_groups.tolist()
        split_type = "SequentialTimeSplit (Single Battery ID)"

    if split_type == "GroupShuffleSplit":
        overlap = set(train_groups).intersection(set(test_groups))
        if overlap:
            raise RULDataValidationError(f"RUL data leakage! Battery IDs overlap between train and test: {overlap}")

    return {
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "train_groups": train_groups,
        "test_groups": test_groups,
        "split_type": split_type
    }


def generate_rul_schema_and_readme(output_dir: Path) -> Tuple[Path, Path]:
    """
    Generates data/training/schema_rul.json and data/training/README_RUL.md detailing
    the required battery RUL training dataset specification.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    readme_path = output_dir / "README_RUL.md"
    schema_path = output_dir / "schema_rul.json"

    schema_data = {
        "dataset_name": "RE-TWIN Battery RUL Training Dataset",
        "expected_filename": "rul_training.csv",
        "target_variable": "rul_target_cycles = eol_cycle - cycle_index (Cycles remaining)",
        "rul_unit": "Cycles remaining",
        "required_columns": {
            "battery_id": "Unique string identifier for battery pack/cell (e.g., 'BAT_PACK_01')",
            "cycle_index": "Integer degradation cycle count (0, 1, 2, ...)",
            "measured_capacity_ah": "Measured discharge capacity in Ampere-hours (Ah)",
            "rated_capacity_ah": "Nominal rated battery capacity in Ampere-hours (Ah)",
            "SOC": "State of Charge percentage (0.0 to 100.0 %)",
            "TempMean": "Mean battery operating temperature in degrees Celsius (°C)",
            "CellVoltageImbalance": "Maximum cell-to-cell voltage imbalance in Volts (V)",
            "PackVoltage": "Total pack terminal voltage in Volts (V)",
            "PackCurrent": "Pack current in Amperes (A)",
            "PackPower_W": "Pack power in Watts (W)",
            "Throughput_Ah": "Cumulative charge throughput in Ampere-hours (Ah)"
        },
        "optional_columns": {
            "eol_cycle": "Documented End-of-Life cycle index (where capacity <= 80% rated)"
        },
        "data_validation_rules": [
            "battery_id must be present for group-based train/val/test splitting.",
            "RUL target is defined as RUL = EOL cycle - Current cycle.",
            "EOL threshold is defined at 80% capacity retention (measured_capacity_ah / rated_capacity_ah <= 0.80).",
            "No future information or target leakage is permitted in operating features.",
            "Synthetic Smart fortwo demonstration telemetry must NEVER be used as real aging data."
        ]
    }

    with open(schema_path, "w", encoding="utf-8") as f:
        json.dump(schema_data, f, indent=2)

    readme_content = """# RE-TWIN Battery RUL Training Dataset Specification

## Location
Expected training dataset file: `data/training/rul_training.csv`

## Overview
This directory is designated for laboratory battery cycler training data used to train scientifically valid Remaining Useful Life (RUL) machine learning models using **Random Forest Regressor**.

## Dataset Schema Requirements

| Column Name | Type | Unit / Format | Required | Description |
|---|---|---|---|---|
| `battery_id` | String | e.g. `"BAT_PACK_01"` | Yes | Battery cell/pack group identifier for leakage-free splitting |
| `cycle_index` | Integer | Count (0, 1, 2, ...) | Yes | Current degradation cycle index |
| `measured_capacity_ah` | Float | Ah | Yes | Measured discharge capacity at reference temperature |
| `rated_capacity_ah` | Float | Ah | Yes | Nominal fresh cell capacity |
| `SOC` | Float | % (0.0 - 100.0) | Yes | State of Charge |
| `TempMean` | Float | °C | Yes | Average battery module temperature |
| `CellVoltageImbalance` | Float | V | Yes | Maximum voltage spread across series cells |
| `PackVoltage` | Float | V | Yes | Total pack voltage |
| `PackCurrent` | Float | A | Yes | Pack current |
| `PackPower_W` | Float | W | Yes | Electrical power |
| `Throughput_Ah` | Float | Ah | Yes | Cumulative charge throughput |
| `eol_cycle` | Integer | Count | Optional | Documented End-of-Life cycle index |

## RUL Target Formula
Remaining Useful Life (RUL) in cycles is defined as:
$$\\text{RUL (cycles)} = \\text{EOL cycle} - \\text{Current cycle}$$

Where EOL (End of Life) is defined as the cycle at which battery capacity drops to $80\\%$ of nominal rated capacity:
$$\\text{Capacity Retention} = \\frac{\\text{Measured Capacity (Ah)}}{\\text{Rated Capacity (Ah)}} \\le 0.80$$

## Missing Dataset Notice
If `data/training/rul_training.csv` is missing, the RUL training pipeline (`src/ml/train_rul.py`) will notify the user and generate this schema specification.
**Synthetic Smart fortwo demonstration data must NEVER be used as real battery aging data.** Real laboratory cycler datasets (e.g. NASA Battery Dataset, CALCE, Oxford, or OEM cycler tests) must be placed in `data/training/rul_training.csv`.
"""

    with open(readme_path, "w", encoding="utf-8") as f:
        f.write(readme_content)

    return schema_path, readme_path
