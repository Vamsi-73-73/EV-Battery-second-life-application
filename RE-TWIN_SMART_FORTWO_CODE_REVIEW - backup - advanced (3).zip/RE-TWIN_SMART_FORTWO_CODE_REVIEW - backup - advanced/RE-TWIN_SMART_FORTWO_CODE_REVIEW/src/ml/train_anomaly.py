"""
Smart fortwo Operational Anomaly Detection Pipeline using Isolation Forest.

Trains sklearn.ensemble.IsolationForest on verified Smart fortwo CAN features.
Evaluates exploratory anomaly score distributions, inspects top anomalous observations,
and serializes model artifacts, metadata, and score predictions.
"""

from pathlib import Path
import sys
import json
from typing import Optional, Dict, Any, List, Tuple
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

# Add project root to sys.path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from src.ml.anomaly_data_validation import (
    prepare_smart_fortwo_anomaly_dataset,
    validate_anomaly_dataset,
    generate_anomaly_schema_and_readme,
    EXPECTED_ANOMALY_OPERATING_FEATURES,
    ANOMALY_FEATURE_SOURCES,
    ANOMALY_FEATURE_UNITS,
    AnomalyDataValidationError
)


def train_anomaly_pipeline(
    data_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
    model_dir: Optional[Path] = None,
    source_txt_path: Optional[Path] = None,
    contamination: float = 0.05,
    random_seed: int = 42
) -> Dict[str, Any]:
    """
    Executes the Smart fortwo Isolation Forest operational anomaly detection training pipeline.
    """
    if data_path is None:
        data_path = ROOT / "data" / "training" / "anomaly_training.csv"
    if output_dir is None:
        output_dir = ROOT / "output" / "ml_predictions"
    if model_dir is None:
        model_dir = ROOT / "models"
    if source_txt_path is None:
        source_txt_path = ROOT / "data" / "smart_fortwo" / "charge_current_soc94_2_to_100.txt"

    training_dir = data_path.parent

    print("=" * 75)
    print("  RE-TWIN: Smart fortwo Operational Anomaly Detection Pipeline (Isolation Forest)")
    print("=" * 75)

    # 1. Prepare/Extract Dataset if missing
    if not data_path.exists():
        if source_txt_path.exists():
            print(f"\n[STATUS] Extracting verified Smart fortwo dataset from: {source_txt_path.name}")
            prepare_smart_fortwo_anomaly_dataset(source_txt_path, data_path)
        else:
            print(f"\n[STATUS] Anomaly training dataset missing at: {data_path}")
            schema_file, readme_file = generate_anomaly_schema_and_readme(training_dir)
            print(f"[ACTION] Generated dataset schema and README:")
            print(f"  - Schema: {schema_file}")
            print(f"  - README: {readme_file}")
            print("\n[EXPLANATION OF MISSING DATA]")
            print("  - Real Smart fortwo CAN dataset or raw charging log is required.")
            print("  - Synthetic demonstration telemetry (ev_pack_drive.csv) is FORBIDDEN.")
            print("=" * 75)
            return {
                "status": "MISSING_DATASET",
                "message": f"Dataset missing at {data_path}. Schema and README generated.",
                "data_path": str(data_path),
                "readme_path": str(readme_file),
                "schema_path": str(schema_file)
            }

    # 2. Load and Validate Dataset
    print(f"\n[1/5] Loading and validating verified Smart fortwo dataset from: {data_path.name}")
    raw_df = pd.read_csv(data_path)
    validated_df, val_report = validate_anomaly_dataset(raw_df, operating_features=EXPECTED_ANOMALY_OPERATING_FEATURES)
    print(f"  - Input rows: {val_report['total_input_rows']}, Validated rows: {val_report['validated_output_rows']}")

    # Extract Feature Matrix X
    X_raw = validated_df[EXPECTED_ANOMALY_OPERATING_FEATURES].copy()

    # 3. Fit Preprocessing & Isolation Forest
    print(f"\n[2/5] Fitting Preprocessing & Isolation Forest (contamination={contamination})...")
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()

    X_imp = imputer.fit_transform(X_raw)
    X_scaled = scaler.fit_transform(X_imp)
    X_df = pd.DataFrame(X_scaled, columns=EXPECTED_ANOMALY_OPERATING_FEATURES, index=X_raw.index)

    iso_forest = IsolationForest(
        n_estimators=100,
        contamination=contamination,
        random_state=random_seed,
        n_jobs=-1
    )
    iso_forest.fit(X_df)

    # 4. Anomaly Decision Function & Scores
    print(f"\n[3/5] Calculating decision function scores and anomaly flags...")
    # decision_function: higher score = normal, lower score = anomalous (offset at 0.0)
    decision_scores = iso_forest.decision_function(X_df)
    # raw_predictions: 1 = normal, -1 = anomaly
    pred_flags = iso_forest.predict(X_df)

    # Convert to user-friendly score format (invert so higher score = more anomalous)
    # anomaly_score = -decision_score
    anomaly_scores = -decision_scores

    validated_df["anomaly_score"] = np.round(anomaly_scores, 4)
    validated_df["anomaly_flag"] = ["ANOMALOUS" if f == -1 else "NORMAL" for f in pred_flags]

    # 5. Exploratory Anomaly Score Distribution Analysis (Phase 4 Validation)
    print(f"\n[4/5] Analyzing anomaly score distributions (Exploratory Analysis)...")
    score_stats = {
        "mean_score": float(np.mean(anomaly_scores)),
        "std_score": float(np.std(anomaly_scores)),
        "min_score": float(np.min(anomaly_scores)),
        "max_score": float(np.max(anomaly_scores)),
        "p5": float(np.percentile(anomaly_scores, 5)),
        "p25": float(np.percentile(anomaly_scores, 25)),
        "p50_median": float(np.percentile(anomaly_scores, 50)),
        "p75": float(np.percentile(anomaly_scores, 75)),
        "p95": float(np.percentile(anomaly_scores, 95)),
        "total_anomalies_detected": int((pred_flags == -1).sum()),
        "anomaly_percentage": float((pred_flags == -1).mean() * 100.0)
    }

    # Inspect top 5 highest-scoring anomaly observations
    top_anomalies_df = validated_df.sort_values("anomaly_score", ascending=False).head(5)
    top_anomalies = []
    for idx, row in top_anomalies_df.iterrows():
        top_anomalies.append({
            "timestamp": str(row.get("timestamp_raw", row.get("timestamp", idx))),
            "SOC": float(row["SOC"]),
            "charge_current_a": float(row["charge_current_a"]),
            "charging_current_limit_command": float(row["charging_current_limit_command"]),
            "charging_current_limit_reply": float(row["charging_current_limit_reply"]),
            "anomaly_score": float(row["anomaly_score"]),
            "plausible_explanation": (
                "Observed current limit step change (14A -> 8A) or low current boundary near end of charge"
                if row["charge_current_a"] < 8.0 or row["charging_current_limit_command"] < 14.0
                else "Unusual feature combination relative to steady-state charging baseline"
            )
        })

    print(f"  - Total Observations: {len(validated_df)}")
    print(f"  - Flagged Anomalies: {score_stats['total_anomalies_detected']} ({score_stats['anomaly_percentage']:.1f}%)")
    print(f"  - Score Range: [{score_stats['min_score']:.4f} to {score_stats['max_score']:.4f}]")
    print(f"  - Top Anomaly Timestamp: {top_anomalies[0]['timestamp']} (Score: {top_anomalies[0]['anomaly_score']:.4f})")

    # 6. Serialize Artifacts
    model_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    iso_model_path = model_dir / "anomaly_isolation_forest.joblib"
    iso_meta_path = model_dir / "anomaly_isolation_forest_metadata.json"
    eval_json_path = output_dir / "anomaly_evaluation.json"
    scores_csv_path = output_dir / "anomaly_scores.csv"

    pipeline_artifact = {
        "imputer": imputer,
        "scaler": scaler,
        "model": iso_forest,
        "feature_names": EXPECTED_ANOMALY_OPERATING_FEATURES,
        "model_type": "Isolation Forest",
        "contamination": contamination,
        "random_seed": random_seed
    }
    joblib.dump(pipeline_artifact, iso_model_path)

    metadata = {
        "model_version": "1.0.0",
        "model_architecture": "Isolation Forest",
        "provenance": "Smart fortwo Real OBD/CAN Capture (Jun 2018)",
        "operating_context": "Level 2 AC Charging (94.2% to 100% SOC)",
        "training_date": pd.Timestamp.now().isoformat(),
        "random_seed": random_seed,
        "contamination_parameter": {
            "value": contamination,
            "interpretation_notice": (
                "The contamination parameter represents an assumed expected anomaly fraction "
                "within the training set, NOT a ground-truth measured anomaly rate."
            )
        },
        "thresholding_method": {
            "decision_function_offset": 0.0,
            "rule": "Samples with decision_function score < 0.0 (inverted anomaly_score > threshold) are flagged as ANOMALOUS."
        },
        "probability_disclaimer": (
            "Anomaly scores represent average isolation path lengths from random decision tree partitions. "
            "They are NOT calibrated statistical probabilities of failure."
        ),
        "feature_schema": {
            "feature_names": EXPECTED_ANOMALY_OPERATING_FEATURES,
            "sources": ANOMALY_FEATURE_SOURCES,
            "units": ANOMALY_FEATURE_UNITS
        },
        "dataset_statistics": {
            "num_samples": len(validated_df),
            "num_features": len(EXPECTED_ANOMALY_OPERATING_FEATURES)
        }
    }
    with open(iso_meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    analysis_payload = {
        "evaluation_timestamp": pd.Timestamp.now().isoformat(),
        "evaluation_type": "Exploratory Unsupervised Anomaly Score Distribution (Unlabeled Data)",
        "score_distribution_statistics": score_stats,
        "top_anomalous_observations": top_anomalies,
        "explicit_disclaimer": (
            "Ground truth anomaly labels are unavailable for the Smart fortwo dataset. "
            "Results are exploratory. Supervised metrics (Precision, Recall, F1, Accuracy) are NOT reported."
        )
    }
    with open(eval_json_path, "w", encoding="utf-8") as f:
        json.dump(analysis_payload, f, indent=2)

    # Save Anomaly Scores CSV
    out_cols = [
        "timestamp_raw", "SOC", "charging_current_limit_command",
        "charging_current_limit_reply", "charge_current_a",
        "anomaly_score", "anomaly_flag", "operating_context", "data_provenance"
    ]
    avail_cols = [c for c in out_cols if c in validated_df.columns]
    scores_df = validated_df[avail_cols].copy()
    scores_df.to_csv(scores_csv_path, index=False)

    def safe_rel(p: Path) -> str:
        try:
            return str(p.relative_to(ROOT))
        except ValueError:
            return str(p)

    print(f"\n[ARTIFACTS SAVED]")
    print(f"  - Model:       {safe_rel(iso_model_path)}")
    print(f"  - Metadata:    {safe_rel(iso_meta_path)}")
    print(f"  - Evaluation:  {safe_rel(eval_json_path)}")
    print(f"  - Scores CSV:  {safe_rel(scores_csv_path)}")

    return {
        "status": "SUCCESS",
        "metadata": metadata,
        "analysis": analysis_payload
    }


if __name__ == "__main__":
    train_anomaly_pipeline()
