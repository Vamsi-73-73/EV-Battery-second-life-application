"""
RE-TWIN — Model Status Management Module.

Provides standardized model status definitions and validation utilities for SOH, RUL,
and Anomaly Detection machine learning models.

Supported States:
1. TRAINED_AND_VALIDATED: Model exists, is loaded, schema matches, and has been validated against held-out data.
2. TRAINED_BUT_NOT_VALIDATED: Model exists and is loaded, but validation on held-out datasets is incomplete or unverified.
3. DATA_UNAVAILABLE: Training dataset is missing or unavailable, preventing model training.
4. MODEL_NOT_TRAINED: Model artifact file is missing from disk or uninstantiated.
5. INPUT_FEATURES_UNAVAILABLE: Required input telemetry features are missing from incoming snapshot.
6. MODEL_INPUT_INCOMPATIBLE: Provided input feature values are non-numeric, infinite, or corrupt.
"""

from enum import Enum
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Union


class ModelStatus(str, Enum):
    TRAINED_AND_VALIDATED = "TRAINED_AND_VALIDATED"
    TRAINED_BUT_NOT_VALIDATED = "TRAINED_BUT_NOT_VALIDATED"
    DATA_UNAVAILABLE = "DATA_UNAVAILABLE"
    MODEL_NOT_TRAINED = "MODEL_NOT_TRAINED"
    INPUT_FEATURES_UNAVAILABLE = "INPUT_FEATURES_UNAVAILABLE"
    MODEL_INPUT_INCOMPATIBLE = "MODEL_INPUT_INCOMPATIBLE"


def get_model_status(
    predictor: Any,
    snapshot_dict: Optional[Dict[str, Any]] = None,
    expected_model_path: Optional[Union[str, Path]] = None,
    training_data_path: Optional[Union[str, Path]] = None,
    is_validated: bool = True
) -> Dict[str, Any]:
    """
    Evaluates exact model status according to Phase 2 guidelines.

    Returns:
        Dict containing:
            - status: ModelStatus value
            - is_usable: bool
            - status_label: Human readable label
            - model_architecture: str
            - provenance: str
            - missing_requirement: Optional[str]
            - feature_schema: List[str]
            - missing_features: List[str]
            - incompatible_features: List[str]
    """
    path = Path(expected_model_path) if expected_model_path else (predictor.model_path if getattr(predictor, "model_path", None) else None)
    train_path = Path(training_data_path) if training_data_path else None

    # Step 1: Check if model object is present
    if getattr(predictor, "model", None) is None:
        if path and not path.exists():
            if train_path and not train_path.exists():
                status = ModelStatus.DATA_UNAVAILABLE
                missing_req = f"Training dataset missing at '{train_path}'. Cannot train model '{path.name}'."
            else:
                status = ModelStatus.MODEL_NOT_TRAINED
                missing_req = f"Model artifact file '{path.name}' is missing or not trained."
        else:
            status = ModelStatus.MODEL_NOT_TRAINED
            missing_req = "Model is not trained or loaded into memory."

        return {
            "status": status.value,
            "is_usable": False,
            "status_label": status.value.replace("_", " "),
            "model_architecture": getattr(predictor, "model_type", "Unknown Model"),
            "provenance": getattr(predictor, "provenance", "Unloaded Model"),
            "missing_requirement": missing_req,
            "feature_schema": getattr(predictor, "feature_names", []),
            "missing_features": [],
            "incompatible_features": []
        }

    # Step 2: Validate input features if snapshot provided
    missing_features = []
    incompatible_features = []
    if snapshot_dict is not None and hasattr(predictor, "validate_input_features"):
        is_valid, missing_features, incompatible_features = predictor.validate_input_features(snapshot_dict)
        if len(missing_features) > 0:
            return {
                "status": ModelStatus.INPUT_FEATURES_UNAVAILABLE.value,
                "is_usable": False,
                "status_label": "INPUT FEATURES UNAVAILABLE",
                "model_architecture": getattr(predictor, "model_type", "Unknown Model"),
                "provenance": getattr(predictor, "provenance", "Model Estimate"),
                "missing_requirement": f"Missing required input features: {', '.join(missing_features)}",
                "feature_schema": getattr(predictor, "feature_names", []),
                "missing_features": missing_features,
                "incompatible_features": incompatible_features
            }
        if len(incompatible_features) > 0:
            return {
                "status": ModelStatus.MODEL_INPUT_INCOMPATIBLE.value,
                "is_usable": False,
                "status_label": "MODEL INPUT INCOMPATIBLE",
                "model_architecture": getattr(predictor, "model_type", "Unknown Model"),
                "provenance": getattr(predictor, "provenance", "Model Estimate"),
                "missing_requirement": f"Incompatible input values: {', '.join(incompatible_features)}",
                "feature_schema": getattr(predictor, "feature_names", []),
                "missing_features": missing_features,
                "incompatible_features": incompatible_features
            }

    # Step 3: Model is loaded and features (if provided) are valid
    if is_validated:
        status = ModelStatus.TRAINED_AND_VALIDATED
    else:
        status = ModelStatus.TRAINED_BUT_NOT_VALIDATED

    return {
        "status": status.value,
        "is_usable": True,
        "status_label": status.value.replace("_", " "),
        "model_architecture": getattr(predictor, "model_type", "Machine Learning Model"),
        "provenance": getattr(predictor, "provenance", "Model Estimate"),
        "missing_requirement": None,
        "feature_schema": getattr(predictor, "feature_names", []),
        "missing_features": [],
        "incompatible_features": []
    }
