"""
RE-TWIN Battery Dataset Validation & Sanitization Module.

Provides comprehensive schema validation, unit conversion verification, missing value checks,
cycle monotonic order checks, and target computation validation for SOH and RUL datasets.
"""

from typing import Dict, List, Tuple, Optional, Any
import numpy as np
import pandas as pd


REQUIRED_BASE_COLUMNS = [
    "battery_id",
    "cycle_index",
    "measured_capacity_ah",
    "rated_capacity_ah"
]

EXPECTED_SOH_FEATURES = [
    "SOC",
    "TempMean",
    "CellVoltageImbalance",
    "PackVoltage",
    "PackCurrent",
    "PackPower_W",
    "Throughput_Ah"
]


class DatasetValidationError(ValueError):
    """Raised when a dataset breaks critical validation rules."""
    pass


def validate_battery_aging_df(
    df: pd.DataFrame,
    required_cols: Optional[List[str]] = None
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Validates a raw or preprocessed battery aging DataFrame.

    Checks:
    1. Presence of required base columns.
    2. Data types and numeric conversions.
    3. Non-negative capacity values.
    4. Duplicate records by (battery_id, cycle_index).
    5. Monotonic cycle ordering within battery groups.

    Returns:
        clean_df: Cleaned and validated DataFrame
        report: Diagnostic dictionary
    """
    if df is None or not isinstance(df, pd.DataFrame) or len(df) == 0:
        raise DatasetValidationError("Provided dataset is empty or invalid DataFrame.")

    check_cols = required_cols or REQUIRED_BASE_COLUMNS
    missing_cols = [c for c in check_cols if c not in df.columns]
    if missing_cols:
        raise DatasetValidationError(f"Missing required columns in dataset: {missing_cols}")

    clean_df = df.copy()

    # 1. Clean string battery_id
    clean_df["battery_id"] = clean_df["battery_id"].astype(str).str.strip()

    # 2. Ensure numeric types for measurements
    num_cols = [c for c in check_cols if c != "battery_id"]
    for col in num_cols:
        clean_df[col] = pd.to_numeric(clean_df[col], errors="coerce")

    # Drop rows where required base metrics are NaN
    initial_len = len(clean_df)
    clean_df = clean_df.dropna(subset=check_cols).copy()
    dropped_nan = initial_len - len(clean_df)

    # 3. Check for non-negative capacities
    invalid_cap_mask = (clean_df["measured_capacity_ah"] <= 0) | (clean_df["rated_capacity_ah"] <= 0)
    dropped_invalid_cap = int(invalid_cap_mask.sum())
    clean_df = clean_df[~invalid_cap_mask].copy()

    # 4. Remove duplicate cycle entries per battery
    clean_df = clean_df.drop_duplicates(subset=["battery_id", "cycle_index"], keep="first").copy()

    # 5. Sort by battery_id and cycle_index
    clean_df["cycle_index"] = clean_df["cycle_index"].astype(int)
    clean_df = clean_df.sort_values(by=["battery_id", "cycle_index"]).reset_index(drop=True)

    report = {
        "initial_rows": initial_len,
        "clean_rows": len(clean_df),
        "dropped_nan_rows": dropped_nan,
        "dropped_invalid_capacity_rows": dropped_invalid_cap,
        "unique_battery_ids": clean_df["battery_id"].unique().tolist(),
        "is_valid": len(clean_df) > 0
    }

    return clean_df, report


def validate_soh_target_schema(
    df: pd.DataFrame
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Validates and calculates State of Health target ratio.

    Formula: SOH (%) = Measured Capacity / Rated Capacity * 100
             soh_target_ratio = Measured Capacity / Rated Capacity

    Clamps target ratio to valid range [0.40, 1.20].
    """
    clean_df, report = validate_battery_aging_df(df, REQUIRED_BASE_COLUMNS)

    clean_df["soh_target_ratio"] = clean_df["measured_capacity_ah"] / clean_df["rated_capacity_ah"]
    clean_df["soh_target_pct"] = clean_df["soh_target_ratio"] * 100.0

    # Clamp extreme outliers
    valid_range_mask = (clean_df["soh_target_ratio"] >= 0.40) & (clean_df["soh_target_ratio"] <= 1.15)
    outliers_count = int((~valid_range_mask).sum())
    clean_df = clean_df[valid_range_mask].copy()

    report["soh_target_calculated"] = True
    report["soh_outliers_removed"] = outliers_count
    report["mean_soh_pct"] = float(round(clean_df["soh_target_pct"].mean(), 2)) if len(clean_df) > 0 else 0.0

    return clean_df, report


def validate_rul_target_schema(
    df: pd.DataFrame,
    eol_capacity_threshold_ah: Optional[float] = None,
    eol_soh_retention_pct: float = 70.0
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Validates and calculates Remaining Useful Life (RUL) target cycles.

    Formula: RUL = EOL cycle - Current cycle

    Where EOL cycle is determined per battery_id as the first cycle index where
    measured capacity drops below eol_capacity_threshold_ah (or eol_soh_retention_pct * rated_capacity).
    """
    clean_df, report = validate_battery_aging_df(df, REQUIRED_BASE_COLUMNS)

    rul_records = []
    battery_ids = clean_df["battery_id"].unique()

    for bat_id in battery_ids:
        bat_df = clean_df[clean_df["battery_id"] == bat_id].sort_values(by="cycle_index").copy()
        rated_cap = bat_df["rated_capacity_ah"].iloc[0]

        threshold = eol_capacity_threshold_ah if eol_capacity_threshold_ah else (rated_cap * (eol_soh_retention_pct / 100.0))

        # Find first cycle where measured capacity <= threshold
        eol_mask = bat_df["measured_capacity_ah"] <= threshold
        if eol_mask.any():
            eol_cycle = int(bat_df.loc[eol_mask, "cycle_index"].iloc[0])
        else:
            # If battery did not reach EOL in dataset, use max observed cycle as EOL upper bound
            eol_cycle = int(bat_df["cycle_index"].max())

        bat_df["eol_cycle"] = eol_cycle
        bat_df["rul_target_cycles"] = (eol_cycle - bat_df["cycle_index"]).clip(lower=0)
        rul_records.append(bat_df)

    processed_df = pd.concat(rul_records, ignore_index=True) if rul_records else pd.DataFrame()

    report["rul_target_calculated"] = True
    report["rul_unit"] = "Cycles remaining"
    report["num_batteries_processed"] = len(battery_ids)

    return processed_df, report
