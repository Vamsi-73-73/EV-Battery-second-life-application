"""
RE-TWIN Dataset Management Package.

Provides data adapters, schema validation, and dataset preparation routines
for real battery-aging datasets (NASA, Oxford, CALCE).
"""

from src.ml.data.dataset_registry import DATASET_REGISTRY, BatteryDatasetInfo
from src.ml.data.dataset_validation import (
    validate_battery_aging_df,
    validate_soh_target_schema,
    validate_rul_target_schema
)

__all__ = [
    "DATASET_REGISTRY",
    "BatteryDatasetInfo",
    "validate_battery_aging_df",
    "validate_soh_target_schema",
    "validate_rul_target_schema"
]
