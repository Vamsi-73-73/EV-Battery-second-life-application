"""
Oxford Battery Degradation Dataset Adapter.

Parses raw Oxford degradation dataset files (Cell 1 through Cell 8), extracts
discharge capacity, cell temperature (40°C test environment), voltage, current, and cycle indices,
and formats into standardized SOH and RUL DataFrames.
"""

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import numpy as np
import pandas as pd

from src.ml.data.dataset_registry import DATASET_REGISTRY
from src.ml.data.dataset_validation import validate_soh_target_schema, validate_rul_target_schema


class OxfordAdapter:
    """Adapter for Oxford University Battery Degradation Dataset."""

    def __init__(self, raw_dir: Optional[Path] = None):
        self.info = DATASET_REGISTRY["OXFORD_DEGRADATION"]
        self.raw_dir = Path(raw_dir) if raw_dir else Path(__file__).resolve().parents[3] / "data" / "training" / "raw" / "oxford"

    def is_dataset_available(self) -> bool:
        """Checks if Oxford raw dataset files exist."""
        if not self.raw_dir.exists():
            return False
        found_files = list(self.raw_dir.glob("*.csv")) + list(self.raw_dir.glob("*.mat"))
        return len(found_files) > 0

    def parse_raw_data(self) -> pd.DataFrame:
        """Parses raw Oxford dataset CSV/MAT files into standardized DataFrame."""
        if not self.is_dataset_available():
            raise FileNotFoundError(f"Oxford raw dataset files not found in '{self.raw_dir}'.")

        records = []
        for csv_file in sorted(self.raw_dir.glob("*.csv")):
            cell_id = csv_file.stem.upper()
            df = pd.read_csv(csv_file)

            for _, row in df.iterrows():
                cap_ah = float(row.get("capacity_ah", row.get("capacity", row.get("measured_capacity_ah", 0.0))))
                cyc = int(row.get("cycle", row.get("cycle_index", 0)))
                temp = float(row.get("temp", 40.0))
                v_pack = float(row.get("voltage", 3.7))
                i_pack = float(row.get("current", 1.5))

                records.append({
                    "battery_id": f"OXFORD_{cell_id}",
                    "cycle_index": cyc,
                    "SOC": 80.0,
                    "TempMean": temp,
                    "CellVoltageImbalance": 0.001,
                    "PackVoltage": v_pack,
                    "PackCurrent": i_pack,
                    "PackPower_W": round(abs(v_pack * i_pack), 2),
                    "Throughput_Ah": round(cyc * 0.74 * 2.0, 2),
                    "measured_capacity_ah": cap_ah,
                    "rated_capacity_ah": self.info.rated_capacity_ah
                })

        return pd.DataFrame(records)

    def extract_soh_dataset(self) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        raw_df = self.parse_raw_data()
        return validate_soh_target_schema(raw_df)

    def extract_rul_dataset(self) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        raw_df = self.parse_raw_data()
        return validate_rul_target_schema(
            raw_df,
            eol_capacity_threshold_ah=self.info.eol_capacity_threshold_ah,
            eol_soh_retention_pct=self.info.eol_soh_retention_pct
        )
