"""
SOH Dataset Preparation Pipeline.

Discovers raw battery-aging datasets (NASA, Oxford, CALCE) in data/training/raw/,
applies dataset adapters, validates schemas and units, computes SOH target ratios,
and outputs standardized data/training/soh_training.csv.
"""

from pathlib import Path
import sys
from typing import Dict, Any, List, Optional
import pandas as pd

# Add project root to sys.path
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from src.ml.data.nasa_adapter import NASAAdapter
from src.ml.data.oxford_adapter import OxfordAdapter
from src.ml.data.calce_adapter import CALCEAdapter
from src.ml.data.dataset_validation import validate_soh_target_schema


def prepare_soh_dataset(
    raw_dir: Optional[Path] = None,
    output_csv: Optional[Path] = None
) -> Dict[str, Any]:
    """
    Ingests available raw datasets and compiles data/training/soh_training.csv.
    """
    raw_root = Path(raw_dir) if raw_dir else ROOT / "data" / "training" / "raw"
    target_csv = Path(output_csv) if output_csv else ROOT / "data" / "training" / "soh_training.csv"
    processed_dir = ROOT / "data" / "training" / "processed"

    print("=" * 75)
    print("  RE-TWIN: Real Battery-Aging SOH Dataset Preparation Pipeline")
    print("=" * 75)

    adapters = [
        ("NASA PCoE", NASAAdapter(raw_root / "nasa")),
        ("Oxford Degradation", OxfordAdapter(raw_root / "oxford")),
        ("CALCE Group", CALCEAdapter(raw_root / "calce"))
    ]

    soh_dfs = []
    integrated_sources = []

    for name, adapter in adapters:
        if adapter.is_dataset_available():
            print(f"[FOUND] Raw dataset files available for: {name}")
            df_soh, report = adapter.extract_soh_dataset()
            soh_dfs.append(df_soh)
            integrated_sources.append({
                "dataset_name": name,
                "rows_extracted": len(df_soh),
                "batteries": report.get("unique_battery_ids", [])
            })
            print(f"  - Extracted {len(df_soh)} rows across batteries: {report.get('unique_battery_ids', [])}")
        else:
            print(f"[NOT PRESENT] Raw dataset directory missing or empty for: {name} ({adapter.raw_dir})")

    if not soh_dfs:
        print("\n[STATUS] No raw battery-aging datasets found in data/training/raw/")
        print("[ACTION] Please download real battery aging data (e.g. NASA B0005/6/7, Oxford, CALCE) into data/training/raw/")
        print("         See data/training/README.md for download URLs, chemistry specs, and column formats.")
        print("=" * 75)
        return {
            "status": "DATA_UNAVAILABLE",
            "message": "No raw battery aging datasets available in data/training/raw/",
            "integrated_sources": [],
            "total_samples": 0
        }

    combined_df = pd.concat(soh_dfs, ignore_index=True)
    clean_soh_df, final_report = validate_soh_target_schema(combined_df)

    # Save to data/training/soh_training.csv and data/training/processed/
    target_csv.parent.mkdir(parents=True, exist_ok=True)
    processed_dir.mkdir(parents=True, exist_ok=True)

    clean_soh_df.to_csv(target_csv, index=False)
    clean_soh_df.to_csv(processed_dir / "soh_processed.csv", index=False)

    print(f"\n[SUCCESS] Compiled SOH training dataset to: {target_csv.relative_to(ROOT) if target_csv.is_relative_to(ROOT) else target_csv}")
    print(f"  - Total Validated Records: {len(clean_soh_df)}")
    print(f"  - Total Unique Batteries: {len(final_report.get('unique_battery_ids', []))}")
    print("=" * 75)

    return {
        "status": "SUCCESS",
        "output_csv": str(target_csv),
        "integrated_sources": integrated_sources,
        "total_samples": len(clean_soh_df),
        "unique_batteries": final_report.get("unique_battery_ids", [])
    }


if __name__ == "__main__":
    prepare_soh_dataset()
