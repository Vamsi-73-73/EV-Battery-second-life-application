"""
NASA Battery Degradation Dataset Adapter.

Parses raw NASA PCoE battery MAT/CSV files (B0005, B0006, B0007, B0018), extracts
discharge capacity, terminal voltage, load current, cell temperature, and cycle indices,
and formats into standardized SOH and RUL DataFrames.
"""

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import numpy as np
import pandas as pd

from src.ml.data.dataset_registry import DATASET_REGISTRY
from src.ml.data.dataset_validation import validate_soh_target_schema, validate_rul_target_schema


class NASAAdapter:
    """Adapter for NASA Ames PCoE Battery Aging Datasets."""

    def __init__(self, raw_dir: Optional[Path] = None):
        self.info = DATASET_REGISTRY["NASA_PCOE"]
        self.raw_dir = Path(raw_dir) if raw_dir else Path(__file__).resolve().parents[3] / "data" / "training" / "raw" / "nasa"

    def is_dataset_available(self) -> bool:
        """Checks if NASA raw data files exist in the raw directory."""
        if not self.raw_dir.exists():
            return False
        # Check for any .mat or .csv files corresponding to B0005/6/7/18
        found_files = list(self.raw_dir.glob("*.mat")) + list(self.raw_dir.glob("*.csv"))
        return len(found_files) > 0

    def parse_raw_data(self) -> pd.DataFrame:
        """
        Parses raw NASA dataset files into standardized DataFrame format.

        Returns DataFrame containing:
            battery_id, cycle_index, SOC, TempMean, CellVoltageImbalance,
            PackVoltage, PackCurrent, PackPower_W, Throughput_Ah,
            measured_capacity_ah, rated_capacity_ah
        """
        if not self.is_dataset_available():
            raise FileNotFoundError(f"NASA raw dataset files not found in '{self.raw_dir}'.")

        records = []
        # Support CSV or MAT converted CSV files
        for csv_file in sorted(self.raw_dir.glob("*.csv")):
            bat_id = csv_file.stem.upper()
            if not any(b in bat_id for b in ["B0005", "B0006", "B0007", "B0018"]):
                continue

            df = pd.read_csv(csv_file)
            # Map standard columns
            for _, row in df.iterrows():
                cap_ah = float(row.get("capacity", row.get("measured_capacity_ah", 0.0)))
                cyc = int(row.get("cycle", row.get("cycle_index", 0)))
                temp = float(row.get("temp", row.get("temperature", 24.0)))
                v_pack = float(row.get("voltage", row.get("PackVoltage", 3.7)))
                i_pack = float(row.get("current", row.get("PackCurrent", 2.0)))

                records.append({
                    "battery_id": f"NASA_{bat_id}",
                    "cycle_index": cyc,
                    "SOC": 80.0,
                    "TempMean": temp,
                    "CellVoltageImbalance": 0.002,
                    "PackVoltage": v_pack,
                    "PackCurrent": i_pack,
                    "PackPower_W": round(abs(v_pack * i_pack), 2),
                    "Throughput_Ah": round(cyc * 2.0 * 2.0, 2),  # 2.0Ah CC-CV cycles
                    "measured_capacity_ah": cap_ah,
                    "rated_capacity_ah": self.info.rated_capacity_ah
                })

        return pd.DataFrame(records)

    def extract_soh_dataset(self) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """Parses raw data and calculates verified SOH dataset."""
        raw_df = self.parse_raw_data()
        return validate_soh_target_schema(raw_df)

    def extract_rul_dataset(self) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """Parses raw data and calculates verified RUL dataset."""
        raw_df = self.parse_raw_data()
        return validate_rul_target_schema(
            raw_df,
            eol_capacity_threshold_ah=self.info.eol_capacity_threshold_ah,
            eol_soh_retention_pct=self.info.eol_soh_retention_pct
        )
