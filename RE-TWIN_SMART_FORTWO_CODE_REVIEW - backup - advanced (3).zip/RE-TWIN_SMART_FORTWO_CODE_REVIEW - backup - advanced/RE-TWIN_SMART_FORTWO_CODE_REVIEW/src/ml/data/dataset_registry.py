"""
RE-TWIN Battery-Aging Dataset Registry.

Centralizes metadata, chemistry parameters, rated capacities, EOL definitions,
source URLs, and licensing info for public battery degradation datasets.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Any


@dataclass
class BatteryDatasetInfo:
    name: str
    source_institution: str
    source_url: str
    chemistry: str
    cell_form_factor: str
    rated_capacity_ah: float
    nominal_voltage_v: float
    eol_capacity_threshold_ah: float
    eol_soh_retention_pct: float
    batteries: List[str]
    temperature_c: float
    license: str
    description: str


DATASET_REGISTRY: Dict[str, BatteryDatasetInfo] = {
    "NASA_PCOE": BatteryDatasetInfo(
        name="NASA Prognostics Center of Excellence Battery Dataset",
        source_institution="NASA Ames Research Center / PCoE",
        source_url="https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/",
        chemistry="NCA / LiCoO2",
        cell_form_factor="18650 Cylindrical",
        rated_capacity_ah=2.0,
        nominal_voltage_v=3.7,
        eol_capacity_threshold_ah=1.4,  # 70% retention
        eol_soh_retention_pct=70.0,
        batteries=["B0005", "B0006", "B0007", "B0018"],
        temperature_c=24.0,
        license="Public Domain (NASA Open Data)",
        description="Repeated charge/discharge cycling tests on 18650 cells at 24°C."
    ),
    "OXFORD_DEGRADATION": BatteryDatasetInfo(
        name="Oxford Battery Degradation Dataset",
        source_institution="Department of Engineering Science, University of Oxford",
        source_url="https://ora.ox.ac.uk/objects/uuid:03ba4f01-059e-4ee8-a5d2-f673322d711c",
        chemistry="NMC / Graphite",
        cell_form_factor="Pouch (Kokam SLPB533496H)",
        rated_capacity_ah=0.74,
        nominal_voltage_v=3.7,
        eol_capacity_threshold_ah=0.592,  # 80% retention
        eol_soh_retention_pct=80.0,
        batteries=["Cell1", "Cell2", "Cell3", "Cell4", "Cell5", "Cell6", "Cell7", "Cell8"],
        temperature_c=40.0,
        license="Creative Commons Attribution 4.0 International (CC BY 4.0)",
        description="Artemis urban drive cycle degradation tests at 40°C with characterization pulses."
    ),
    "CALCE_DEGRADATION": BatteryDatasetInfo(
        name="CALCE Battery Research Group Dataset",
        source_institution="Center for Advanced Life Cycle Engineering, University of Maryland",
        source_url="https://calce.umd.edu/battery-data",
        chemistry="LiCoO2 / NMC",
        cell_form_factor="Pouch / Cylindrical (CS2 & CX2)",
        rated_capacity_ah=1.1,
        nominal_voltage_v=3.7,
        eol_capacity_threshold_ah=0.88,  # 80% retention
        eol_soh_retention_pct=80.0,
        batteries=["CS2_33", "CS2_34", "CS2_35", "CS2_36", "CX2_33", "CX2_34"],
        temperature_c=25.0,
        license="Educational / Research Open Access",
        description="Constant-current cycling tests under various charge/discharge C-rates."
    )
}


def get_supported_datasets() -> List[str]:
    """Returns list of registered dataset keys."""
    return list(DATASET_REGISTRY.keys())


def get_dataset_info(dataset_key: str) -> Optional[BatteryDatasetInfo]:
    """Retrieves metadata for a registered dataset."""
    return DATASET_REGISTRY.get(dataset_key)


def validate_dataset_compatibility(dataset_key: str, target_vehicle_chemistry: str = "Smart fortwo 451 ED (LiFePO4/NMC)") -> Dict[str, Any]:
    """
    Checks compatibility between dataset chemistry/conditions and Smart fortwo target specs.
    """
    info = get_dataset_info(dataset_key)
    if not info:
        return {"compatible": False, "error": f"Unknown dataset key: {dataset_key}"}

    chem_match = "LiFePO4" in info.chemistry or "NMC" in info.chemistry
    limitations = []

    if not chem_match:
        limitations.append(f"Chemistry mismatch: Dataset uses {info.chemistry}, target vehicle uses LiFePO4/NMC.")

    limitations.append(f"Form factor difference: Dataset tested on {info.cell_form_factor}.")
    limitations.append(f"Capacity scale difference: Cell rated capacity is {info.rated_capacity_ah} Ah vs Smart fortwo pack ~52 Ah.")

    return {
        "dataset_name": info.name,
        "chem_match": chem_match,
        "cell_form_factor": info.cell_form_factor,
        "rated_capacity_ah": info.rated_capacity_ah,
        "limitations": limitations
    }

