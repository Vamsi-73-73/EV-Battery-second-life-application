# RE-TWIN — Real Battery-Aging Dataset Preparation Guide

This directory contains experimentally measured battery-aging datasets, preprocessing adapters, and standardized schemas for **State of Health (SOH)** prediction and **Remaining Useful Life (RUL)** estimation models.

---

## 1. Directory Structure

```text
data/training/
├── raw/                      # Original, unmodified downloaded datasets (NASA, Oxford, CALCE)
├── processed/                # Standardized intermediate clean datasets
├── soh_training.csv          # Consolidated SOH training dataset
├── rul_training.csv          # Consolidated RUL training dataset
├── anomaly_training.csv      # Verified Smart fortwo OBD/CAN AC charging dataset
├── schema.json               # Standardized feature and target schema definitions
└── README.md                 # Dataset provenance and preparation guide
```

---

## 2. Supported Public Battery-Aging Datasets

### A. NASA Prognostics Center of Excellence Battery Dataset
- **Source**: NASA Ames Research Center / PCoE
- **URL**: `https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/`
- **Cell Chemistry**: Lithium Nickel Cobalt Aluminum Oxide (NCA / LiCoO2 baseline)
- **Cell Specs**: 18650 cylindrical cells, **Rated Capacity = 2.0 Ah**, Nominal Voltage = 3.7 V
- **Batteries**: `B0005`, `B0006`, `B0007`, `B0018`
- **Test Protocol**: Repeated charge/discharge cycles at 24 °C ambient temperature.
  - Charge: 1.5A CC to 4.2V, then CV until current dropped to 20mA.
  - Discharge: 2.0A CC down to 2.7V (B0005), 2.5V (B0006), 2.2V (B0007), 2.5V (B0018).
- **EOL Threshold**: 30% capacity loss (**1.4 Ah measured capacity**, 70% SOH retention).
- **Usage License**: Public Domain (NASA PCoE Open Data).

### B. Oxford Battery Degradation Dataset
- **Source**: Department of Engineering Science, University of Oxford
- **URL**: `https://ora.ox.ac.uk/objects/uuid:03ba4f01-059e-4ee8-a5d2-f673322d711c`
- **Cell Chemistry**: Lithium Nickel Manganese Cobalt Oxide (NMC / Graphite)
- **Cell Specs**: Kokam SLPB533496H pouch cells, **Rated Capacity = 0.74 Ah** (740 mAh)
- **Batteries**: `Cell 1` through `Cell 8`
- **Test Protocol**: Drive cycle profiles applied at 40 °C in thermal chamber with periodic EIS characterization.
- **EOL Threshold**: 20% capacity loss (**0.592 Ah measured capacity**, 80% SOH retention).

### C. CALCE Battery Research Group Dataset
- **Source**: Center for Advanced Life Cycle Engineering (CALCE), University of Maryland
- **URL**: `https://calce.umd.edu/battery-data`
- **Cell Chemistry**: LiCoO2 / NMC
- **Cell Specs**: CS2 & CX2 pouch cells, **Rated Capacity = 1.1 Ah**
- **Batteries**: `CS2_33`, `CS2_34`, `CS2_35`, `CS2_36`, `CX2_33`, `CX2_34`
- **Test Protocol**: Constant current charge/discharge cycling with varying discharge C-rates (0.5C to 2C).
- **EOL Threshold**: 20% capacity loss (**0.88 Ah measured capacity**, 80% SOH retention).

---

## 3. Data Schema Definitions

### SOH Training Dataset (`soh_training.csv`)

| Field Name | Type | Unit | Description | Provenance |
| :--- | :--- | :--- | :--- | :--- |
| `battery_id` | `str` | N/A | Unique cell/pack identifier (e.g. `NASA_B0005`) | REAL DATASET |
| `cycle_index` | `int` | cycles | Test cycle sequence number | REAL DATASET |
| `SOC` | `float` | % | Operating State of Charge | REAL DATASET |
| `TempMean` | `float` | °C | Average cell temperature during test | REAL DATASET |
| `CellVoltageImbalance` | `float` | V | Maximum series cell voltage delta | REAL DATASET |
| `PackVoltage` | `float` | V | Measured terminal voltage | REAL DATASET |
| `PackCurrent` | `float` | A | Measured load/charge current | REAL DATASET |
| `PackPower_W` | `float` | W | Calculated electrical power ($V \times I$) | DERIVED |
| `Throughput_Ah` | `float` | Ah | Cumulative Ah charge/discharge throughput | DERIVED |
| `measured_capacity_ah` | `float` | Ah | Measured discharge capacity at current cycle | REAL DATASET |
| `rated_capacity_ah` | `float` | Ah | Manufacturer nominal rated capacity | REAL DATASET |
| `soh_target_ratio` | `float` | ratio | Measured SOH fraction ($\text{Capacity} / \text{Rated}$) | TARGET (DERIVED) |

### RUL Training Dataset (`rul_training.csv`)

| Field Name | Type | Unit | Description | Provenance |
| :--- | :--- | :--- | :--- | :--- |
| `battery_id` | `str` | N/A | Unique cell identifier (e.g. `NASA_B0005`) | REAL DATASET |
| `cycle_index` | `int` | cycles | Current cycle index | REAL DATASET |
| `SOC` | `float` | % | Operating State of Charge | REAL DATASET |
| `TempMean` | `float` | °C | Test temperature | REAL DATASET |
| `CellVoltageImbalance` | `float` | V | Voltage imbalance | REAL DATASET |
| `PackVoltage` | `float` | V | Terminal voltage | REAL DATASET |
| `PackCurrent` | `float` | A | Terminal current | REAL DATASET |
| `PackPower_W` | `float` | W | Power ($V \times I$) | DERIVED |
| `Throughput_Ah` | `float` | Ah | Cumulative Ah throughput | DERIVED |
| `measured_capacity_ah` | `float` | Ah | Discharge capacity | REAL DATASET |
| `eol_cycle` | `int` | cycles | Cycle at which capacity reached EOL threshold | TARGET (DERIVED) |
| `rul_target_cycles` | `float` | cycles | Remaining Useful Life ($EOL - \text{Current Cycle}$) | TARGET (DERIVED) |

---

## 4. Scientific Rules & Constraints

1. **No Synthetic Data Generation**: Do NOT invent synthetic capacity measurements, fake cycle logs, or dummy labels.
2. **Leakage Prevention**:
   - `battery_id` is used ONLY for group-based train/test splitting. It MUST NOT be passed as a feature to regression models.
   - Future-cycle measurements (e.g. capacity from cycle $N+10$) MUST NOT be included in input features for cycle $N$.
   - Preprocessing fit (imputer & scaler) MUST occur strictly on training battery splits.
3. **Smart fortwo Applicability Disclaimer**: Models trained on laboratory single-cell cycling datasets (NASA 18650, Oxford pouch) reflect laboratory degradation mechanisms. They are NOT certified vehicle-level SOH/RUL predictions for the Smart fortwo pack without in-vehicle dataset validation.
